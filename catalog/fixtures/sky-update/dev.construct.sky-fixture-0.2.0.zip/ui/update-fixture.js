'use strict';
// Clearly synthetic data for an independent-module-update test, not live traffic.
const realBridgeCall = call;
call = function(method, params) {
  if (method === 'net.http' && params.url.startsWith('https://api.adsb.lol/')) {
    return Promise.resolve({status:200,headers:{},text:JSON.stringify({now:Date.now(),ac:[
      {hex:'abc123',flight:'SYNTHETIC',r:'TEST-ONLY',t:'BE30',category:'A1',
       lat:50.05,lon:8.56,alt_baro:6000,gs:180,track:90,seen_pos:0}
    ]})});
  }
  return realBridgeCall(method, params);
};
