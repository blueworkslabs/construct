'use strict';
let count = 0;
const countView = document.getElementById('count');
call('storage.kv',{op:'get',key:'counter'}).then(value=>{
  count = typeof value === 'number' ? value : 0;
  countView.textContent = 'Counter: ' + count;
}).catch(error=>{countView.textContent='Storage error: '+error.code;});
document.getElementById('add').onclick=async()=>{
  await call('storage.kv',{op:'set',key:'counter',value:++count});
  countView.textContent='Counter: '+count;
};
document.getElementById('probe').onclick=async()=>{
  const result=document.getElementById('result');
  // Authorization is checked before origin validation. This deliberately
  // undeclared destination is rejected locally even when HTTP is granted.
  try {
    await call('net.http',{op:'get',url:'https://example.net/consent-probe',format:'json'});
    result.textContent='HTTP result: UNEXPECTED SUCCESS';
  } catch(error) { result.textContent='HTTP result: '+error.code; }
};
