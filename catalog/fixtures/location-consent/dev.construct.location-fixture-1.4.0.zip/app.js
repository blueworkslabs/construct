'use strict';
let count = 0;
const countView = document.getElementById('count');
call('storage.kv',{op:'get',key:'counter'}).then(value=>{
  count = typeof value === 'number' ? value : 0;
  countView.textContent = 'Counter: ' + count;
}).catch(error=>{countView.textContent='Storage error: '+error.code;});
document.getElementById('add').onclick=async()=>{
  await call('storage.kv',{op:'set',key:'counter',value:++count});
  countView.textContent='Counter: '+count;
};
document.getElementById('probe').onclick=async()=>{
  const result=document.getElementById('result');
  // No OS permission is granted in this fixture. An invalid op also
  // prevents a position request if permission were already present.
  try {
    const value=await call('location.read',{op:'get'});
    result.textContent='Location result: '+(value.approximate?'APPROXIMATE':'PRECISE');
  } catch(error) { result.textContent='Location result: '+error.code; }
};
