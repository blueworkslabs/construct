'use strict';
const el=id=>document.getElementById(id),canvas=el('board'),ctx=canvas.getContext('2d');
let game=SnakeModel.fresh(),previous=game,playing=false,saving=false,fault=false,loading=true,queuedTurn=null;
let lastStep=0,animationStart=0,gesture=null,raf=0;
const seed=()=>Math.floor(Math.random()*4294967296);
function label() {
  const head=game.snake[0],food=game.food;
  canvas.setAttribute('aria-label',`Game board. Head ${head[0]+1}, ${head[1]+1}. Facing ${game.direction}. Moves ${game.moves}.`);
  el('score').textContent='Score '+game.score;el('best').textContent='Best '+game.best;
  el('play').textContent=game.moves?'Resume':'Play';
  el('play').disabled=loading||fault||saving||playing||game.mode!=='alive';
  el('pause').disabled=!playing;
  el('new').disabled=loading||fault||saving||playing;
  for(const d of Object.keys(SnakeModel.vectors))el(d).disabled=!playing||fault;
  el('retry').disabled=loading||saving;el('discard').disabled=loading||saving;
  el('overlay').hidden=playing&&!fault;
  el('overlay').textContent=loading?'Loading…':fault?'Save unavailable':game.mode==='over'?'Game over':game.mode==='won'?'Board cleared!':game.moves?'Paused':'Ready?';
}
function draw(now) {
  const bounds=canvas.getBoundingClientRect(),ratio=Math.min(window.devicePixelRatio||1,2),width=Math.max(1,Math.round(bounds.width*ratio));
  if(canvas.width!==width||canvas.height!==width){canvas.width=width;canvas.height=width;}
  const unit=width/SnakeModel.size;
  ctx.fillStyle='#172d29';ctx.fillRect(0,0,width,width);
  ctx.strokeStyle='#254139';ctx.lineWidth=1;
  for(let i=1;i<SnakeModel.size;i++){ctx.beginPath();ctx.moveTo(i*unit,0);ctx.lineTo(i*unit,width);ctx.moveTo(0,i*unit);ctx.lineTo(width,i*unit);ctx.stroke();}
  if(game.food){const[x,y]=game.food;ctx.fillStyle='#f6ba72';ctx.beginPath();ctx.arc((x+.5)*unit,(y+.5)*unit,unit*.32,0,Math.PI*2);ctx.fill();}
  const blend=playing?Math.min(1,Math.max(0,(now-animationStart)/80)):1;
  game.snake.forEach((cell,i)=>{
    const from=previous.snake[Math.min(i,previous.snake.length-1)]||cell;
    const x=from[0]+(cell[0]-from[0])*blend,y=from[1]+(cell[1]-from[1])*blend;
    ctx.fillStyle=i===0?'#e3f7b0':'#8bcba0';ctx.fillRect((x+.08)*unit,(y+.08)*unit,unit*.84,unit*.84);
    if(i===0){const[dx,dy]=SnakeModel.vectors[game.direction];ctx.fillStyle='#173126';ctx.beginPath();ctx.arc((x+.5+dx*.19)*unit,(y+.5+dy*.19)*unit,unit*.1,0,Math.PI*2);ctx.fill();}
  });
}
function fail(error) {
  playing=false;queuedTurn=null;fault=true;el('retry').hidden=false;
  el('status').textContent='Saving unavailable ['+(error.code||'STORAGE_ERROR')+']. Paused; check Module access, then retry.';label();
}
async function persist(next,message) {
  saving=true;label();
  try {
    await call('storage.kv',{op:'set',key:'game',value:next});
    previous=game;game=next;animationStart=performance.now();
    if(game.mode!=='alive'){playing=false;queuedTurn=null;}
    if(message)el('status').textContent=message;
    else if(game.mode==='over')el('status').textContent='Game over. Best score saved.';
    else if(game.mode==='won')el('status').textContent='All fruit collected. Best score saved.';
    return true;
  } catch(error){fail(error);return false;}
  finally {saving=false;label();draw(performance.now());}
}
function pause(message='Paused. Reopen or Resume when ready.') {
  playing=false;queuedTurn=null;el('status').textContent=message;label();draw(performance.now());
}
function turn(direction) {
  if(!playing||fault||queuedTurn!==null||!SnakeModel.canTurn(game,direction))return;
  queuedTurn=direction;
}
async function load() {
  if(saving)return;
  loading=true;playing=false;queuedTurn=null;fault=false;el('retry').hidden=true;el('repair').hidden=true;el('confirm').hidden=true;label();
  try {
    const saved=await call('storage.kv',{op:'get',key:'game'});
    if(saved!==null&&!SnakeModel.valid(saved)){fault=true;el('repair').hidden=false;el('status').textContent='Unsupported saved game. Nothing was changed.';return;}
    game=saved||SnakeModel.fresh(seed());previous=game;
    el('status').textContent=saved?'Saved game loaded; paused.':'Swipe or use the arrows. Fruit makes you faster.';
  }catch(error){fail(error);}
  finally {loading=false;label();draw(performance.now());}
}
el('play').onclick=()=>{
  if(loading||saving||fault||game.mode!=='alive'||playing)return;
  playing=true;queuedTurn=null;previous=game;lastStep=performance.now();el('status').textContent='Playing. Moves and best score save on this phone.';label();
};
el('pause').onclick=()=>pause();
el('new').onclick=()=>{if(!playing&&!saving&&!loading&&!fault)persist(SnakeModel.fresh(seed(),game.best),'New game ready. Best score kept.');};
for(const d of Object.keys(SnakeModel.vectors))el(d).onclick=()=>turn(d);
window.addEventListener('keydown',event=>{
  const direction={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right'}[event.key];
  if(direction){event.preventDefault();turn(direction);}
  else if(event.key===' '){event.preventDefault();if(playing)pause();else el('play').onclick();}
});
canvas.addEventListener('pointerdown',event=>{if(!event.isPrimary)return;gesture={id:event.pointerId,x:event.clientX,y:event.clientY};canvas.setPointerCapture(event.pointerId);});
canvas.addEventListener('pointerup',event=>{
  if(!gesture||gesture.id!==event.pointerId)return;
  const dx=event.clientX-gesture.x,dy=event.clientY-gesture.y;gesture=null;
  if(Math.max(Math.abs(dx),Math.abs(dy))<14)return;
  turn(Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up'));
});
canvas.addEventListener('pointercancel',()=>{gesture=null;});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='visible')pause('Paused after leaving the game.');});
window.addEventListener('resize',()=>{if(playing)pause('Paused after resizing. Resume when ready.');draw(performance.now());});
el('retry').onclick=()=>{if(!loading&&!saving)load();};
el('discard-open').onclick=()=>{el('confirm').hidden=false;};el('keep').onclick=()=>{el('confirm').hidden=true;};
el('discard').onclick=async()=>{if(loading||saving)return;if(await persist(SnakeModel.fresh(seed()),'Saved game and best reset.')){fault=false;el('repair').hidden=true;label();}};
function frame(now) {
  if(playing&&!saving&&!fault&&!loading){
    const elapsed=now-lastStep;
    if(elapsed>1000)pause('Paused after an interruption. Resume when ready.');
    else if(elapsed>=SnakeModel.interval(game)){
      const direction=queuedTurn;queuedTurn=null;lastStep=now;
      persist(SnakeModel.step(game,direction));
    }
  }
  if(playing)draw(now);
  raf=requestAnimationFrame(frame);
}
load();raf=requestAnimationFrame(frame);
