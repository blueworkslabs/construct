"use strict";
(() => {
  const $ = (id) => document.getElementById(id),
    O = SpaceOrbit,
    K = SpaceSky,
    C = SpaceCatalog,
    P = SpacePlan;
  // The acceptance fixture pins the clock; the product uses the phone's.
  const fixture = typeof SpaceFixture !== "undefined" ? SpaceFixture : null,
    now = () => (fixture ? fixture.now() : Date.now());
  const MINUTE = 60000,
    HOUR = 60 * MINUTE,
    ELEMENTS_TTL = 8 * HOUR,
    ELEMENTS_MANUAL = 2 * HOUR,
    SATCAT_TTL = 7 * 24 * HOUR,
    BACKOFF = 2 * HOUR,
    RETRY = 15 * MINUTE,
    ELEMENT_CHUNKS = 8,
    SATCAT_CHUNKS = 4,
    RECENT_CHUNKS = 4,
    PLAN_HOURS = 12,
    OLD_DATA = 72 * HOUR;
  let place = null,
    objects = [],
    satcat = new Map(),
    recent = [],
    launchDates = new Map(),
    trainList = [],
    plan = null,
    planKey = "",
    meta = { elements: 0, satcat: 0, recent: 0 },
    fetchState = { last: 0, until: 0, satcatLast: 0, satcatUntil: 0, recentLast: 0, recentUntil: 0 },
    prefs = { startWithLocation: true, red: false, layers: { gnss: false, geo: false } },
    selected = null,
    selectedPass = null,
    offset = 0,
    active = true,
    epoch = 0,
    busy = false,
    locating = false,
    locationRequest = 0,
    fetching = false,
    dataMessage = { text: "", tone: "" },
    sky = { stars: null, starsAt: 0, bodies: null, bodiesAt: 0 },
    listKey = "",
    lastCounts = "",
    infoTarget = null,
    infoGeneration = 0,
    infoBusy = false,
    wikiDone = false,
    wikiSection = null;
  // The space-data mirror (C.MIRROR): index cached for 30 minutes; after a
  // failure it rests for 30 minutes and CelesTrak is used directly.
  const mirror = { index: null, at: 0, until: 0 };
  // Optional layers, loaded from the mirror only while switched on. Too large
  // for storage.kv, so they are downloaded again on each open.
  const LAYER_NAMES = { gnss: "Navigation", geo: "Geostationary" };
  const layers = {
    gnss: { objects: [], byId: new Map(), satcat: new Map(), at: 0, tried: 0, note: "" },
    geo: { objects: [], byId: new Map(), satcat: new Map(), at: 0, tried: 0, note: "" },
  };
  const layerSky = { gnss: null, geo: null },
    layerDescribed = new Map();
  let belt = null;
  const described = new Map(),
    passes = new Map(),
    ends = new Map(),
    launches = new Map();
  // Follow mode state (see "follow mode" below); declared early for frame().
  // pointing: the phone is raised like a camera; attitude is its smoothed
  // orientation (SpacePointer frame) while pointing.
  const follow = { on: false, want: false, heading: null, accuracy: null, calibrate: false, pose: null, trueNorth: false, unavailable: false, lastSample: 0, request: 0, expiry: null, pointing: false, attitude: null };
  let spotAz = null,
    lastSky = null;
  const message = (el, text, tone = "") => {
    if (el.textContent !== text) el.textContent = text;
    if (el.className !== tone) el.className = tone;
  };
  const element = (tag, text, className) => {
    const e = document.createElement(tag);
    if (text != null) e.textContent = text;
    if (className) e.className = className;
    return e;
  };
  const interrupted = () =>
    Object.assign(new Error("Request interrupted."), { code: "RUN_PAUSED" });
  const denied = (e) =>
    e.code === "CAPABILITY_DENIED" || e.code === "LOCATION_PERMISSION";
  const describeError = (e) =>
    ({
      CAPABILITY_DENIED:
        "Enable the requested capability in Construct’s Module access, then reopen.",
      LOCATION_PERMISSION:
        "Enable Allow reading phone location and Android location access in Module access, then reopen.",
      LOCATION_TIMEOUT:
        "No location fix within 12 seconds. Move nearer a window, try again or enter coordinates.",
      LOCATION_UNAVAILABLE:
        "No location provider is available. Check the phone’s location setting or enter coordinates.",
      LOCATION_BUSY: "A location request is already running.",
      LOCATION_RATE: "Wait 15 seconds between location requests.",
      LOCATION_CANCELLED: "Location request cancelled.",
      RUN_PAUSED: "Return to the module and retry.",
      HTTP_BUSY: "Requests are busy; retry shortly.",
      HTTP_RATE: "Internet request budget reached; wait a minute.",
      HTTP_UNAVAILABLE: "No connection to the data source. Check the internet connection.",
      HTTP_DATA: "The data source sent something unexpected.",
      TIMEOUT: "Construct did not answer in time. Retry.",
    })[e.code] ||
    e.message ||
    "Request unavailable.";
  const time = (ms) =>
    new Date(ms).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  function day(ms) {
    const a = new Date(now()),
      b = new Date(ms),
      same = (x, y) => x.toDateString() === y.toDateString();
    if (same(a, b)) return `today ${time(ms)}`;
    a.setDate(a.getDate() + 1);
    if (same(a, b)) return `tomorrow ${time(ms)}`;
    return `${b.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" })} ${time(ms)}`;
  }
  const km = (x) => `${Math.round(x).toLocaleString("en-US")} km`;
  function age(ms) {
    const h = ms / HOUR;
    if (h < 1) return "less than an hour";
    if (h < 48) return `${Math.round(h)} h`;
    return `${Math.round(h / 24)} days`;
  }

  // ---- storage: preferences, fetch timing and the compact orbit cache ----
  async function kvGet(key) {
    try {
      return await call("storage.kv", { op: "get", key });
    } catch (_) {
      return null;
    }
  }
  async function kvSet(key, value) {
    try {
      await call("storage.kv", { op: "set", key, value });
      return true;
    } catch (_) {
      return false;
    }
  }
  // Chunks first, index last: a torn write leaves a generation mismatch, not bad data.
  async function saveRows(name, rowList, at, max) {
    const parts = O.chunks(rowList);
    if (!parts.length) parts.push([]);
    if (parts.length > max) return false;
    for (let i = 0; i < max; i++)
      if (!(await kvSet(`${name}.${i}`, i < parts.length ? { g: at, r: parts[i] } : null)))
        return false;
    return kvSet(`${name}.meta`, { at, n: parts.length });
  }
  async function loadRows(name, check, max) {
    const m = await kvGet(`${name}.meta`);
    if (!m || !Number.isFinite(m.at) || !Number.isInteger(m.n) || m.n < 1 || m.n > max)
      return { at: 0, rows: [] };
    if (m.at > now() + 5 * MINUTE) return { at: 0, rows: [] };
    const out = [];
    for (let i = 0; i < m.n; i++) {
      const c = await kvGet(`${name}.${i}`);
      if (!c || c.g !== m.at || !Array.isArray(c.r)) return { at: 0, rows: [] };
      for (const r of c.r) {
        const v = check(r);
        if (!v) return { at: 0, rows: [] };
        out.push(v);
      }
    }
    return { at: m.at, rows: out };
  }
  const savePrefs = () => kvSet("preferences", prefs);
  const saveFetchState = () => kvSet("fetch-state", fetchState);
  async function initPrefs() {
    const p = await kvGet("preferences");
    if (p && typeof p === "object") {
      if (typeof p.startWithLocation === "boolean")
        prefs.startWithLocation = p.startWithLocation;
      if (typeof p.red === "boolean") prefs.red = p.red;
      if (p.layers && typeof p.layers === "object")
        for (const k of ["gnss", "geo"]) if (typeof p.layers[k] === "boolean") prefs.layers[k] = p.layers[k];
    }
    const f = await kvGet("fetch-state");
    if (f && typeof f === "object")
      for (const k of ["last", "until", "satcatLast", "satcatUntil", "recentLast", "recentUntil"])
        if (Number.isFinite(f[k])) fetchState[k] = Math.max(0, Math.min(now() + 86400000, f[k]));
    applyRed();
    $("start-with-location").checked = prefs.startWithLocation;
  }
  async function initCache() {
    const e = await loadRows("elements", O.validRow, ELEMENT_CHUNKS);
    if (e.rows.length) {
      objects = O.build(e.rows);
      meta.elements = e.at;
    }
    const s = await loadRows("satcat", C.validRow, SATCAT_CHUNKS);
    if (s.rows.length) {
      satcat = C.index(s.rows);
      meta.satcat = s.at;
    }
    const r = await loadRows("recent", O.validRow, RECENT_CHUNKS),
      dates = await kvGet("recent-launches");
    if (r.at && dates && dates.at === r.at && Array.isArray(dates.d)) {
      recent = O.build(P.trainRows(r.rows));
      launchDates = new Map(dates.d.filter(validLaunch));
      meta.recent = r.at;
      rebuildTrains();
    }
  }
  const validLaunch = (x) =>
    Array.isArray(x) && x.length === 2 && /^\d{4}-\d{3}$/.test(x[0]) && /^\d{4}-\d\d-\d\d$/.test(x[1]);
  function rebuildTrains() {
    const key = (trains) => trains.map(t => `${t.id}:${t.centre.id}:${t.members.map(m => m.id).join()}`).join("|");
    const next = P.trains(recent, launchDates, now()), changed = key(next) !== key(trainList);
    trainList = next;
    described.clear();
    listKey = "";
    if (changed) planKey = "";
  }
  const ready = Promise.all([initPrefs(), initCache()]);

  // ---- network: CelesTrak lists, launch siblings and Wikipedia text ----
  async function getJson(url) {
    if (!active) throw interrupted();
    const e = epoch,
      r = await call("net.http", { op: "get", url, format: "json" });
    if (e !== epoch || !active) throw interrupted();
    return r;
  }
  const MIRROR_RETRY = 30 * MINUTE;
  async function mirrorIndex(t) {
    if (mirror.index && t - mirror.at < 30 * MINUTE && t - mirror.index.built < 12 * HOUR) return mirror.index;
    mirror.index = null;
    if (t < mirror.until) return null;
    try {
      const r = await getJson(C.MIRROR_INDEX),
        idx = r.status === 200 ? C.parseMirrorIndex(r.text, now()) : null;
      if (!idx) {
        mirror.until = t + MIRROR_RETRY;
        return null;
      }
      mirror.index = idx;
      mirror.at = t;
      return idx;
    } catch (e) {
      if (e.code === "RUN_PAUSED") throw e;
      mirror.until = t + MIRROR_RETRY;
      return null;
    }
  }
  // Every row of every file of one group/kind, each checked like cached rows;
  // null (and a rest for the mirror) when anything is missing or off.
  async function mirrorRows(t, group, kind, check, max) {
    const idx = await mirrorIndex(t),
      files = idx && idx.groups[group] && idx.groups[group][kind];
    if (!files) return null;
    const out = [], seen = new Set();
    try {
      for (const url of files) {
        const r = await getJson(url),
          list = r.status === 200 ? C.parseMirrorFile(r.text, kind) : null;
        if (!list || !list.length) throw new Error("mirror file");
        for (const x of list) {
          const v = check(x);
          if (!v || seen.has(v[0]) || out.length >= max) throw new Error("mirror row");
          seen.add(v[0]);
          out.push(v);
        }
      }
    } catch (e) {
      if (e.code === "RUN_PAUSED") throw e;
      mirror.index = null;
      mirror.until = t + MIRROR_RETRY;
      return null;
    }
    return out;
  }
  const dataStatus = (text, tone = "") => {
    dataMessage = { text, tone };
    renderDataStatus();
  };
  function renderDataStatus() {
    const el = $("data-status");
    if (dataMessage.text) return message(el, dataMessage.text, dataMessage.tone);
    if (!objects.length) return message(el, fetching ? "Downloading orbit data from CelesTrak…" : "No orbit data yet.");
    // The orbits' own epochs, not the download time, say how fresh positions are.
    const old = O.ageHours(objects, now()) * HOUR;
    if (old > OLD_DATA)
      return message(el, `Orbit data is ${age(old)} old; positions may be off by minutes. Refresh when online.`, "attention");
    message(el, `Orbit data ${age(old)} old · CelesTrak${fetching ? " · updating…" : ""}`);
  }
  async function fetchElements(t) {
    const previous = fetchState.last;
    fetchState.last = t;
    try {
      let rows = await mirrorRows(t, "visual", "elements", O.validRow, 5000);
      rows = rows && rows.length >= 10 ? rows.slice(0, O.MAX_OBJECTS) : null;
      if (!rows) {
        const r = await getJson(C.ELEMENTS_URL);
        if (r.status !== 200) {
          fetchState.until = t + (r.status === 403 || r.status === 429 ? BACKOFF : RETRY);
          throw new Error(`CelesTrak orbit data unavailable (HTTP ${r.status}).`);
        }
        rows = O.parseElements(r.text);
      }
      if (rows.length < 10) {
        fetchState.until = t + BACKOFF;
        throw new Error("CelesTrak sent no usable orbit data.");
      }
      objects = O.build(rows);
      described.clear();
      listKey = "";
      meta.elements = t;
      fetchState.until = 0;
      passes.clear();
      ends.clear();
      dataMessage = { text: "", tone: "" };
      frame();
      await saveRows("elements", rows, t, ELEMENT_CHUNKS);
    } catch (e) {
      if (e.code === "CAPABILITY_DENIED") fetchState.last = previous;
      if (e.code === "RUN_PAUSED") {
        // An attempt the menu interrupted does not count toward the spacing.
        fetchState.last = previous;
        throw e;
      }
      if (e.code === "HTTP_DATA" || e.code === "HTTP_SIZE") fetchState.until = t + BACKOFF;
      dataMessage = {
        text: objects.length ? `${describeError(e)} Showing the saved orbits.` : describeError(e),
        tone: "attention",
      };
    } finally {
      await saveFetchState();
    }
  }
  async function fetchSatcat(t) {
    const previous = fetchState.satcatLast;
    fetchState.satcatLast = t;
    try {
      let rows = await mirrorRows(t, "visual", "satcat", C.validRow, 5000);
      rows = rows && rows.length >= 10 ? rows.slice(0, 400) : null;
      if (!rows) {
        const r = await getJson(C.SATCAT_URL);
        if (r.status === 403 || r.status === 429) fetchState.satcatUntil = t + BACKOFF;
        if (r.status !== 200) return;
        rows = C.parseSatcat(r.text);
      }
      if (rows.length < 10) {
        fetchState.satcatUntil = t + BACKOFF;
        return;
      }
      satcat = C.index(rows);
      meta.satcat = t;
      fetchState.satcatUntil = 0;
      described.clear();
      listKey = "";
      await saveRows("satcat", rows, t, SATCAT_CHUNKS);
    } catch (e) {
      if (e.code === "CAPABILITY_DENIED") fetchState.satcatLast = previous;
      if (e.code === "HTTP_DATA" || e.code === "HTTP_SIZE") fetchState.satcatUntil = t + BACKOFF;
      if (e.code === "RUN_PAUSED") {
        fetchState.satcatLast = previous;
        throw e;
      }
      /* Descriptions fall back to the object names. */
    } finally {
      await saveFetchState();
    }
  }
  // Trains: recent launches, only the batches that can still fly as a line.
  async function fetchRecent(t) {
    const previous = fetchState.recentLast;
    fetchState.recentLast = t;
    try {
      // Mirror rows are already compact and checked; the same launch-ID rule
      // applies. Any doubt falls back to CelesTrak's own answer.
      let parsed = await mirrorRows(t, "last-30-days", "elements", O.validRow, 20000);
      const fromMirror = !!parsed && !parsed.some((x) => !x[2]);
      if (!fromMirror) {
        const r = await getJson(C.RECENT_URL);
        if (r.status === 403 || r.status === 429) fetchState.recentUntil = t + BACKOFF;
        if (r.status !== 200) return;
        let raw = null;
        try { raw = JSON.parse(r.text); } catch (_) { /* Checked below. */ }
        // The generic orbit parser permits unknown launch IDs. Grouping cannot:
        // incomplete provider records must not become a successful empty snapshot.
        if (!Array.isArray(raw) || raw.some(o => !O.compact(o)?.[2]))
          throw Object.assign(new Error("Invalid recent orbit data"), { code: "HTTP_DATA" });
        // The ordinary visual parser caps at 400. Recent feeds must be grouped
        // in full (the host bounds response bytes), not truncated mid-batch.
        parsed = [...new Map(raw.map(o => { const r = O.compact(o); return [r[0], r]; })).values()];
      }
      const rows = P.trainRows(parsed);
      let dates = new Map();
      const catalog = rows.length && fromMirror ? await mirrorRows(t, "last-30-days", "satcat", C.validRow, 20000) : null;
      if (catalog && catalog.length && !catalog.some((x) => !x[9])) dates = P.launchDates(catalog);
      else if (rows.length) {
        const q = await getJson(C.RECENT_SATCAT_URL);
        if (q.status === 403 || q.status === 429) fetchState.recentUntil = t + BACKOFF;
        if (q.status !== 200) return;
        let rawCatalog = null;
        try { rawCatalog = JSON.parse(q.text); } catch (_) { /* Checked below. */ }
        if (!Array.isArray(rawCatalog) || !rawCatalog.length || rawCatalog.some(o => !C.compact(o)?.[9]))
          throw Object.assign(new Error("Invalid recent catalog"), { code: "HTTP_DATA" });
        dates = P.launchDates(rawCatalog.map(o => C.compact(o)));
      }
      const keep = new Set(rows.map((x) => x[2].slice(0, 8)));
      // Orbit and catalog feeds can lag one another. A launch date cannot
      // change, so preserve known metadata when the fresh catalog omits it.
      for (const key of keep) if (!dates.has(key) && launchDates.has(key)) dates.set(key, launchDates.get(key));
      recent = O.build(rows);
      launchDates = new Map([...dates].filter(([k]) => keep.has(k)));
      meta.recent = t;
      fetchState.recentUntil = 0;
      rebuildTrains();
      frame();
      // Retain the entire source batch for each detected train, including
      // stragglers: otherwise reopening changes “9 of 11” into “9 of 9”.
      const batches = new Set(trainList.map((x) => x.intdes)),
        kept = rows.filter((x) => batches.has(x[2].slice(0, 8)));
      if (await saveRows("recent", kept, t, RECENT_CHUNKS))
        await kvSet("recent-launches", { at: t, d: [...launchDates] });
    } catch (e) {
      if (e.code === "HTTP_DATA" || e.code === "HTTP_SIZE") fetchState.recentUntil = t + BACKOFF;
      if (e.code === "RUN_PAUSED" || e.code === "CAPABILITY_DENIED") fetchState.recentLast = previous;
      if (e.code === "RUN_PAUSED") throw e;
      /* Trains are optional; the bright-object sky works without them. */
    } finally {
      await saveFetchState();
    }
  }
  // One optional layer from the mirror. No CelesTrak fallback: the layers
  // are extras, and CelesTrak's big lists are what the mirror is for.
  async function fetchLayer(name, t) {
    const L = layers[name];
    if (L.loading) return;
    const previous = L.tried;
    L.loading = true;
    try {
      L.tried = t;
      const rows = await mirrorRows(t, name, "elements", O.validRow, 5000);
      if (!rows || !rows.length) {
        L.note = `${LAYER_NAMES[name]} satellites come from the Space Watch data mirror, which is not reachable right now. Retrying in a while.`;
        renderLayers();
        return;
      }
      const cat = await mirrorRows(t, name, "satcat", C.validRow, 5000);
      L.objects = O.build(rows);
      L.byId = new Map(L.objects.map((o) => [o.id, o]));
      L.satcat = cat ? C.index(cat) : new Map();
      L.at = t;
      L.note = "";
      layerSky[name] = null;
      for (const o of L.objects) layerDescribed.delete(name + ":" + o.id);
      frame();
    } catch (e) {
      if (e.code === "RUN_PAUSED") L.tried = previous;
      throw e;
    } finally {
      L.loading = false;
    }
  }

  async function refreshData(manual = false) {
    if (fetching || !active) return;
    const t = now(),
      old = t - meta.elements;
    let wantElements =
      !objects.length || old > ELEMENTS_TTL || (manual && old > ELEMENTS_MANUAL);
    // A server back-off always holds; automatic attempts are also spaced out.
    const waitUntil = Math.max(fetchState.until, manual ? 0 : fetchState.last + RETRY);
    if (wantElements && t < waitUntil) {
      wantElements = false;
      if (manual && t < fetchState.until)
        dataStatus(`CelesTrak asked for a pause; try again after ${time(fetchState.until)}.`, "attention");
    } else if (manual && !wantElements && objects.length) {
      dataStatus(`Downloaded ${age(old)} ago; CelesTrak updates every few hours, so there is nothing newer yet.`);
      setTimeout(() => dataStatus(""), 8000);
      return;
    }
    fetching = true;
    renderDataStatus();
    $("refresh").disabled = true;
    try {
      if (wantElements) await fetchElements(t);
      const covered = objects.filter((o) => satcat.has(o.id)).length;
      if (
        objects.length &&
        t >= fetchState.satcatUntil &&
        (covered < objects.length * 0.9 || t - meta.satcat > SATCAT_TTL) &&
        t - fetchState.satcatLast > RETRY
      )
        await fetchSatcat(t);
      if (
        objects.length &&
        t - meta.recent > ELEMENTS_TTL &&
        t >= fetchState.recentUntil &&
        t - fetchState.recentLast > RETRY
      )
        await fetchRecent(t);
      for (const name of ["gnss", "geo"])
        if (prefs.layers[name] && (!layers[name].at || t - layers[name].at > ELEMENTS_TTL) && t - layers[name].tried > RETRY)
          await fetchLayer(name, t);
    } catch (_) {
      /* Paused: the next visible tick retries. */
    } finally {
      fetching = false;
      $("refresh").disabled = false;
      renderDataStatus();
      frame();
    }
  }

  // ---- the sky at one moment ----
  function info(o) {
    let d = described.get(o.id);
    if (!d) {
      d = C.describe(o, satcat.get(o.id));
      described.set(o.id, d);
    }
    return d;
  }
  function trainInfo(train) {
    let d = described.get(train.id);
    if (!d) {
      const since = train.launch ? Math.floor((now() - Date.parse(train.launch + "T00:00:00Z")) / 86400000) : null;
      d = {
        title: `${train.family} train`,
        kind: `${train.members.length} satellites in a line${train.launch ? ` · launched ${since < 1 ? "today" : since === 1 ? "yesterday" : since + " days ago"}` : ""}`,
        wiki: train.wiki,
        major: true,
        since,
      };
      described.set(train.id, d);
    }
    return d;
  }
  // Prefer a member that can actually be spotted now, rather than letting a
  // low/shadowed cluster centre hide the already-visible end of the train.
  function trainRepresentative(train, t) {
    if (!place) return train.centre;
    const sunAlt = sunAt(t);
    let highest = null;
    for (const o of train.members) {
      const l = O.look(o, place.ob, t);
      if (!l) continue;
      if (O.state(l, sunAlt) === "visible") return o;
      if (!highest || l.el > highest.l.el) highest = { o, l };
    }
    return highest ? highest.o : train.centre;
  }
  function layerInfo(o, name, t) {
    let d = layerDescribed.get(name + ":" + o.id);
    if (!d) {
      d = C.describeLayer(o, layers[name].satcat.get(o.id), name, name === "geo" ? O.subLon(o, t) : null);
      layerDescribed.set(name + ":" + o.id, d);
    }
    return d;
  }
  const catalogOf = (id, layer) => (layer ? layers[layer].satcat.get(id) : satcat.get(id));
  // An id is a NORAD number, or "train:YYYY-NNN" for a train. Objects of a
  // layer are found only while that layer is on.
  function find(id, t = now()) {
    if (typeof id === "string") {
      const train = trainList.find((x) => x.id === id);
      return train ? { id, o: trainRepresentative(train, t), train, d: trainInfo(train) } : null;
    }
    const o = objects.find((x) => x.id === id);
    if (o) return { id, o, train: null, d: info(o) };
    for (const name of ["gnss", "geo"]) {
      const lo = prefs.layers[name] && layers[name].byId.get(id);
      if (lo) return { id, o: lo, train: null, d: layerInfo(lo, name, t), layer: name };
    }
    return null;
  }
  // Layer objects above the horizon. Navigation satellites move slowly and
  // are recomputed every 5 s; geostationary ones hardly move (every 60 s).
  // An object in two groups (a BeiDou IGSO is navigation and geosynchronous)
  // appears once, in the first layer that is on; find() agrees.
  function layerSnapshot(t) {
    const items = [], seen = new Set();
    for (const name of ["gnss", "geo"]) {
      if (!prefs.layers[name]) continue;
      const L = layers[name];
      let c = layerSky[name];
      if (!c || c.place !== place || c.n !== L.objects.length || Math.abs(t - c.t) > (name === "geo" ? 60000 : 5000)) {
        c = { t, place, n: L.objects.length, items: [] };
        for (const o of L.objects) {
          const l = O.look(o, place.ob, t);
          if (l && l.el >= 0) c.items.push({ id: o.id, o, l, layer: name, state: "faint", d: layerInfo(o, name, t) });
        }
        c.items.sort((a, b) => b.l.el - a.l.el);
        layerSky[name] = c;
      }
      for (const item of c.items) {
        if (!seen.has(item.id)) { seen.add(item.id); items.push(item); }
      }
    }
    return items;
  }
  const shortLabel = (o, d) =>
    d.title.endsWith(" train") ? d.title : o.id === 25544 ? "ISS" : o.id === 48274 ? "Tiangong" : o.id === 20580 ? "Hubble" : d.major ? d.title : o.name;
  const sunAt = (ms) => K.sun(ms, place.aob).el;
  function context(t) {
    if (!sky.stars || Math.abs(t - sky.starsAt) > 20000) {
      sky.stars = K.stars(t, place.aob);
      sky.starsAt = t;
    }
    if (!sky.bodies || Math.abs(t - sky.bodiesAt) > 20000) {
      sky.bodies = K.bodies(t, place.aob);
      sky.bodiesAt = t;
    }
  }
  function snapshot(t) {
    const sunAlt = sunAt(t),
      items = [];
    for (const o of objects) {
      const l = O.look(o, place.ob, t);
      if (!l || l.el < 0) continue;
      items.push({ id: o.id, o, l, state: O.state(l, sunAlt), d: info(o) });
    }
    for (const train of trainList) {
      const o = trainRepresentative(train, t),
        l = O.look(o, place.ob, t);
      if (!l || l.el < 0) continue;
      items.push({ id: train.id, o, train, l, state: O.state(l, sunAlt), d: trainInfo(train) });
    }
    const rank = { visible: 0, low: 1, shadow: 2, daylight: 2 };
    items.sort((a, b) => rank[a.state] - rank[b.state] || b.l.el - a.l.el);
    return { t, sunAlt, items };
  }
  let dome = null;
  function frame() {
    if (!place || !active) return;
    if (follow.on && (follow.heading !== null || follow.attitude !== null) && Date.now() - follow.lastSample > 1500) {
      clearHeading();
      renderFollow();
    }
    const t = now() + offset * 1000;
    context(t);
    const s = snapshot(t),
      visible = s.items.filter((x) => x.state === "visible").length;
    s.layers = layerSnapshot(t);
    lastSky = s;
    if (prefs.layers.geo && (!belt || belt.place !== place)) belt = { place, points: K.geoBelt(place.lat, place.lon) };
    dome.set({
      stars: sky.stars,
      asterisms: K.asterisms,
      bodies: sky.bodies,
      dark: s.sunAlt < O.DARK_SUN,
      red: prefs.red,
      follow: follow.on && follow.heading !== null,
      selected,
      layers: s.layers.map((x) => ({ id: x.id, az: x.l.az, el: x.l.el, kind: x.layer, parked: x.d.geo === "parked", label: x.id === selected ? x.o.name : null })),
      belt: prefs.layers.geo && belt ? belt.points : null,
      objects: s.items.map((x) => ({
        id: x.id,
        az: x.l.az,
        el: x.l.el,
        state: x.state,
        major: x.d.major,
        label: x.d.major || x.id === selected ? shortLabel(x.o, x.d) : null,
        trail:
          x.state === "visible" || x.state === "low" || x.id === selected
            ? O.trail(x.o, place.ob, t)
            : null,
        members: x.train
          ? x.train.members
              .filter((m) => m !== x.o)
              .map((m) => O.look(m, place.ob, t))
              .filter((m) => m && O.state(m, s.sunAlt) === "visible")
          : null,
      })),
    });
    const counts = `${visible} visible · ${s.items.length} above you`;
    if (counts !== lastCounts) {
      lastCounts = counts;
      $("counts").textContent = objects.length ? counts : "No orbit data yet";
      $("counts").className = visible ? "chip live" : "chip";
      $("dome").setAttribute(
        "aria-label",
        `Sky dome: ${counts}. The Overhead now list has the same objects as text.`,
      );
    }
    let note = "";
    if (objects.length) {
      if (s.sunAlt >= O.DARK_SUN)
        note = "The sky is too bright to see satellites now. The dome still shows where they are.";
      else if (!visible && s.items.length)
        note = "Nothing sunlit high enough right now: the objects above you are in Earth’s shadow or low.";
      else if (!s.items.length)
        note = "None of the bright objects are above you right now.";
    }
    $("sky-note").textContent = note;
    renderList(s);
    renderLayers(s);
    renderSpot(s);
    $("rewind-label").textContent = offset > 0 ? `Preview ${time(t)}` : K.ago(offset);
    $("now").hidden = offset === 0;
    planStart();
    renderPlan();
    renderPoint();
  }

  // ---- visible passes over the next hours, worked out in small slices ----
  let planTimer = 0;
  function planStart() {
    if (!place || !objects.length) return;
    const t = now(),
      key = `${place.lat},${place.lon}|${meta.elements}|${meta.recent}|${trainList.length}`;
    if (plan && planKey === key && t - plan.from < 30 * MINUTE) return;
    planKey = key;
    // Buffer the refresh interval; renderPlan still exposes only the rolling
    // next 12 hours, including passes that enter that window before refresh.
    const ranges = P.darkRanges(t, t + PLAN_HOURS * HOUR + 30 * MINUTE, sunAt),
      // One queue entry per object keeps each slice to a single scan; a train
      // contributes one entry per distinct member, merged when rendering.
      queue = [
        ...trainList.flatMap((tr) => P.planMembers(tr).map((o) => ({ id: tr.id, o }))),
        ...objects.map((o) => ({ id: o.id, o })),
      ];
    plan = { from: t, ranges, queue, i: 0, results: [], done: !ranges.length, shown: "" };
    schedulePlan();
  }
  function planStep(budgetMs = 15) {
    if (!plan || plan.done || !active || !place) return;
    const started = Date.now();
    while (plan.i < plan.queue.length) {
      const q = plan.queue[plan.i++];
      for (const p of P.passes(q.o, place.ob, plan.ranges, sunAt)) plan.results.push({ ...p, id: q.id });
      if (Date.now() - started > budgetMs) break;
    }
    if (plan.i >= plan.queue.length) plan.done = true;
    renderPlan();
    schedulePlan();
  }
  function schedulePlan() {
    if (plan && !plan.done && !planTimer)
      planTimer = setTimeout(() => {
        planTimer = 0;
        planStep();
      }, 30);
  }
  const START = { rises: "rises", shadow: "comes out of Earth’s shadow", daylight: "appears as the sky darkens", ongoing: "already visible" },
    END = { sets: "sets", shadow: "fades into Earth’s shadow", daylight: "fades in the brightening sky", window: "still visible at window end" };
  function passLine(p) {
    const secs = (p.endMs - p.startMs) / 1000,
      mins = secs < 45 ? "under 1" : String(Math.max(1, Math.round(secs / 60)));
    const top = p.maxEl >= 75 ? (p.maxEl >= 84 ? "passes straight overhead" : "passes almost overhead") : `highest ${K.height(p.maxEl)} in the ${K.dir16(p.maxAz)}`;
    return `${K.dir16(p.startAz)} → ${K.dir16(p.endAz)} · ${top} · ${mins} min${p.endReason === "shadow" ? " · fades into shadow" : ""}`;
  }
  // Train members are planned separately; merge them into one pass per train.
  function planned() {
    if (plan.merged && plan.merged.n === plan.results.length) return plan.merged.list;
    const trains = new Map(),
      list = [];
    for (const p of plan.results) {
      if (typeof p.id !== "string") list.push(p);
      else if (trains.has(p.id)) trains.get(p.id).push(p);
      else trains.set(p.id, [p]);
    }
    for (const [id, parts] of trains) for (const m of P.mergePasses(parts)) list.push({ ...m, id });
    plan.merged = { n: plan.results.length, list };
    return list;
  }
  function renderPlan() {
    if (!plan) return;
    const t = now(),
      list = planned()
        .filter((p) => p.endMs >= t && p.startMs <= t + PLAN_HOURS * HOUR && find(p.id))
        .sort((a, b) => a.startMs - b.startMs)
        .slice(0, 10),
      key = list.map((p) => p.id + ":" + p.startMs + ":" + (p.startMs <= t)).join() + "|" + plan.i + "|" + plan.done + "|" + Math.floor(t / MINUTE) + "|" + selected + "|" + selectedPass + "|" + (offset > 0);
    if (key === plan.shown) return;
    plan.shown = key;
    $("plan-status").textContent = !plan.ranges.length
      ? "The sky here stays too bright for satellites in the next 12 hours."
      : !plan.done
        ? `Working out passes… ${Math.round((100 * plan.i) / plan.queue.length)}%`
        : list.length
          ? "Tap one to preview it on the dome."
          : "No visible passes of the bright objects in the next 12 hours.";
    $("plan-list").replaceChildren(
      ...list.map((p) => {
        const f = find(p.id),
          b = element("button", null, "object pass");
        b.dataset.id = String(p.id);
        b.setAttribute("aria-pressed", String(p.id === selected && p.startMs === selectedPass && offset > 0));
        b.append(
          element("strong", `${p.startMs <= t ? "Now" : time(p.startMs)} · ${f.d.title}`),
          element("span", passLine(p)),
          element("span", `${START[p.startReason]} ${K.dir16(p.startAz)}, ${END[p.endReason]} ${K.height(p.endEl)} in the ${K.dir16(p.endAz)}`),
        );
        b.onclick = () => previewPass(p);
        return b;
      }),
    );
  }
  // Show the dome shortly after the pass becomes visible; it then runs in real time.
  function previewPass(p) {
    // Pointing is live even when a pass is selected after the phone was raised.
    // Keep the object selection, but never hide a future sky behind the viewfinder.
    const live = follow.on && follow.pointing;
    offset = live ? 0 : Math.max(0, Math.round((P.previewTime(p, now()) - now()) / 1000));
    $("rewind").value = "0";
    plan.shown = "";
    select(p.id, true, live ? null : p.startMs);
  }
  function listLine(x) {
    const where = `${K.dir16(x.l.az)} · ${K.height(x.l.el)}`,
      state = { visible: "visible", low: "low", shadow: "in Earth’s shadow", daylight: "daylight" }[x.state];
    return `${where} · ${state}`;
  }
  function renderList(s) {
    const key = s.items.map((x) => x.id + x.state).join() + "|" + selected + "|" + selectedPass + "|" + (offset > 0);
    if (key !== listKey) {
      listKey = key;
      const rows = s.items.map((x) => {
        const b = element("button", null, `object${x.state === "visible" ? " visible" : ""}`);
        b.dataset.id = String(x.id);
        b.setAttribute("aria-pressed", String(x.id === selected));
        b.append(element("strong", x.d.title), element("span", listLine(x)));
        b.onclick = () => select(x.id, true);
        return b;
      });
      $("list").replaceChildren(...rows);
      $("list-title").textContent = offset > 0 ? `Overhead at ${time(now() + offset * 1000)}` : offset ? `Overhead ${K.ago(offset)}` : "Overhead now";
    } else {
      const byId = new Map(s.items.map((x) => [String(x.id), x]));
      for (const b of $("list").children) {
        const x = byId.get(b.dataset.id);
        if (x && b.children[1]) b.children[1].textContent = listLine(x);
      }
    }
  }
  // The layers section: a summary per switched-on layer and, behind "List
  // them", one button per object above the horizon (the dome is an image).
  const layerKeys = { gnss: "", geo: "" };
  function layerSummary(name, items) {
    const L = layers[name];
    if (L.note && !L.at) return L.note;
    if (!L.at) return `Loading ${LAYER_NAMES[name].toLowerCase()} satellites…`;
    if (name === "gnss") {
      const by = new Map();
      for (const x of items) {
        const f = x.d.family === "augmentation (SBAS)" ? "augmentation" : x.d.family;
        by.set(f, (by.get(f) || 0) + 1);
      }
      const parts = [...by].sort((a, b) => b[1] - a[1]).map(([f, n]) => `${n} ${f}`);
      return `${items.length} navigation satellites above you${parts.length ? ": " + parts.join(", ") : ""}. Drawn as small squares.`;
    }
    const top = belt && belt.points.length ? belt.points.reduce((a, b) => (b.el > a.el ? b : a)) : null,
      where = top ? `, strung along the dotted belt ${K.height(top.el)} in the ${K.dir8(top.az).toLowerCase()}` : "",
      parked = items.filter((x) => x.d.geo === "parked").length,
      other = items.length - parked;
    return `${parked} geostationary satellites above you${where}. Drawn as small diamonds${other ? `, plus ${other} inclined or drifting geosynchronous ones as hollow diamonds whose positions change over time` : ""}.${L.note ? " " + L.note : ""}`;
  }
  function renderLayers(s) {
    const any = prefs.layers.gnss || prefs.layers.geo;
    $("layer-section").hidden = !any;
    for (const name of ["gnss", "geo"]) {
      const block = $(`layer-${name}`), on = prefs.layers[name];
      block.hidden = !on;
      if (!on) {
        layerKeys[name] = "";
        continue;
      }
      const items = (s ? s.layers : []).filter((x) => x.layer === name);
      message($(`layer-${name}-summary`), layerSummary(name, items));
      const key = items.map((x) => x.id).join() + "|" + selected;
      if (key !== layerKeys[name]) {
        layerKeys[name] = key;
        $(`layer-${name}-list`).replaceChildren(
          ...items.map((x) => {
            const b = element("button", null, "object");
            b.dataset.id = String(x.id);
            b.setAttribute("aria-pressed", String(x.id === selected));
            b.append(element("strong", x.d.title), element("span", `${K.dir16(x.l.az)} · ${K.height(x.l.el)}`));
            b.onclick = () => select(x.id, true);
            return b;
          }),
        );
      } else {
        const byId = new Map(items.map((x) => [String(x.id), x]));
        for (const b of $(`layer-${name}-list`).children) {
          const x = byId.get(b.dataset.id);
          if (x && b.children[1]) b.children[1].textContent = `${K.dir16(x.l.az)} · ${K.height(x.l.el)}`;
        }
      }
    }
  }
  function showLayers() {
    $("layer-gnss-switch").checked = prefs.layers.gnss;
    $("layer-geo-switch").checked = prefs.layers.geo;
    $("layers-status").textContent = "";
    $("layers-dialog").showModal();
  }
  function setLayer(name, on) {
    prefs.layers[name] = on;
    savePrefs();
    layerKeys[name] = "";
    layerSky.geo = null;
    if (on && place && active && !layers[name].at) {
      layers[name].note = "";
      fetchLayer(name, now()).catch(() => {});
    }
    frame();
    $("layers-status").textContent = `${LAYER_NAMES[name]} ${on ? "on" : "off"}.`;
  }
  $("layers").onclick = showLayers;
  $("layer-gnss-switch").onchange = () => setLayer("gnss", $("layer-gnss-switch").checked);
  $("layer-geo-switch").onchange = () => setLayer("geo", $("layer-geo-switch").checked);
  $("close-layers").onclick = () => $("layers-dialog").close();
  let spotPassRequest = 0;
  function renderSpot(s) {
    const request = ++spotPassRequest;
    if (selected === null) {
      $("spot").hidden = true;
      return;
    }
    const found = find(selected, s.t);
    if (!found) {
      selected = null;
      spotAz = null;
      $("spot").hidden = true;
      return;
    }
    const { o, d, train, layer } = found,
      l = O.look(o, place.ob, s.t),
      st = layer ? (l && l.el >= 0 ? "faint" : "below") : O.state(l, s.sunAlt);
    $("spot").hidden = false;
    $("spot-title").textContent = d.title;
    $("spot-kind").textContent = d.kind;
    $("spot-when").hidden = offset === 0;
    $("spot-when").textContent = offset > 0 ? `At ${time(s.t)}:` : offset ? `${K.ago(offset)}:` : "";
    if (!l || st === "below") {
      spotAz = null;
      renderTurn();
      $("spot-head").textContent = "Below your horizon";
      if (train) {
        $("spot-anchor").textContent = "Working out the next member above you…";
        nextTrainPass(train, s.t, () => selected === train.id && request === spotPassRequest,
          p => { $("spot-anchor").textContent = trainRiseText(p); });
      } else if (d.geo === "parked") {
        $("spot-anchor").textContent = "Below your horizon now. Even near-geostationary satellites move slightly; horizon visibility can change.";
      } else {
        const p = nextPass(o, s.t);
        $("spot-anchor").textContent = p
          ? `Next time above you: ${day(p.riseMs)}, up to ${K.height(p.maxEl)}${layer ? "" : p.visible ? ", visible" : ", not visible (shadow or daylight)"}.`
          : "Not above you in the next 36 hours.";
      }
      $("spot-motion").textContent = "";
      $("spot-state").textContent = "";
      for (const id of ["stat-alt", "stat-speed", "stat-range"]) $(id).textContent = "–";
      if (l) {
        $("stat-alt").textContent = km(l.altKm);
        $("stat-speed").textContent = `${l.speedKms.toFixed(1)} km/s`;
        $("stat-range").textContent = km(l.rangeKm);
      }
      return;
    }
    const an = K.anchor(l, K.anchors(sky.bodies, sky.stars, s.sunAlt));
    $("spot-head").textContent = K.headline(l);
    spotAz = offset === 0 ? l.az : null;
    renderTurn();
    $("spot-anchor").textContent = an ? an.text : "";
    $("spot-motion").textContent = d.geo === "parked"
      ? d.inclination >= 1
        ? `It stays near this spot, wobbling about ${Math.round(d.inclination)}° north and south over each day.`
        : "It stays near this spot: its orbit nearly matches Earth’s rotation. Small daily motion remains."
      : K.motion(l, O.look(o, place.ob, s.t + MINUTE), O.look(o, place.ob, s.t + 4 * MINUTE));
    const end = !train && st === "visible" && offset === 0 ? passEnd(o, s.t) : null;
    const line = train
      ? `A line of ${train.members.length} satellites; early orbits are rough, so look along the track ahead and behind`
      : d.geo === "parked"
        ? "Satellite dishes aimed at it point approximately this way"
        : layer === "geo"
          ? "Geosynchronous but not parked: its position changes relative to the dotted belt"
          : layer === "gnss"
          ? "Your phone’s location fix can use signals from satellites like this one"
          : "";
    $("spot-state").textContent = [K.STATE[st], K.ending(end), line].filter(Boolean).join(". ");
    $("stat-alt").textContent = km(l.altKm);
    $("stat-speed").textContent = `${l.speedKms.toFixed(1)} km/s`;
    $("stat-range").textContent = km(l.rangeKm);
  }
  // Cached per object: the end of a pass moves little within ten seconds.
  function passEnd(o, t) {
    const c = ends.get(o.id);
    if (c && Math.abs(c.t - t) < 10000 && c.end)
      return { ...c.end, inS: Math.max(0, (c.end.atMs - t) / 1000) };
    const end = O.passEnd(o, place.ob, t, sunAt);
    ends.set(o.id, { t, end });
    return end;
  }
  function nextPass(o, t) {
    const c = passes.get(o.id);
    if (c && t >= c.t && t - c.t < 5 * MINUTE && (!c.p || c.p.riseMs > t)) return c.p;
    const p = O.nextPass(o, place.ob, t, sunAt);
    passes.set(o.id, { t, p });
    return p;
  }
  const trainRiseCache = new Map();
  const trainRiseText = p => p
    ? `Next member above you: ${day(p.riseMs)} · ${p.visible ? "visible" : "not visible"}`
    : "No member rises above 10° in the next 36 hours.";
  // Both grouped views use the same bounded, cancellable member search.
  function nextTrainPass(train, t, current, done) {
    const origin = place, startedEpoch = epoch;
    const valid = () => active && place === origin && epoch === startedEpoch && current();
    const cached = trainRiseCache.get(train.id);
    if (cached && cached.train === train && cached.place === origin && t >= cached.t &&
        t - cached.t < 5 * MINUTE && (!cached.p || cached.p.riseMs > t)) {
      if (valid()) done(cached.p);
      return;
    }
    const members = P.planMembers(train);
    let best = null, i = 0;
    function step() {
      if (!valid()) return;
      const p = nextPass(members[i++], t);
      if (p && (!best || p.riseMs < best.riseMs)) best = p;
      if (i < members.length) setTimeout(step, 0);
      else {
        trainRiseCache.set(train.id, { train, place: origin, t, p: best });
        done(best);
      }
    }
    setTimeout(step, 0);
  }
  function select(id, fromList = false, passStart = null) {
    selected = id;
    selectedPass = passStart;
    listKey = "";
    frame();
    if (fromList && id !== null) $("spot").scrollIntoView({ block: "nearest" });
  }

  // ---- details: the lookup layer ----
  function facts(title, pairs) {
    const section = element("section");
    section.append(element("h3", title));
    const dl = element("dl");
    for (const [k, v] of pairs) {
      if (v == null || v === "") continue;
      const row = element("div", null, "fact");
      row.append(element("dt", k), element("dd", v));
      dl.append(row);
    }
    section.append(dl);
    return section;
  }
  function openInfo() {
    const found = find(selected);
    if (!found || !place) return;
    const o = found.o;
    infoTarget = o;
    const generation = ++infoGeneration;
    infoBusy = false;
    wikiDone = false;
    const d = found.d,
      train = found.train,
      c = train ? null : catalogOf(o.id, found.layer),
      t = now(),
      l = O.look(o, place.ob, t),
      p = train || found.d.geo === "parked" ? null : nextPass(o, t);
    $("info-title").textContent = d.title;
    $("info-kind").textContent = d.kind;
    const body = $("info-body");
    body.replaceChildren();
    if (l && l.el >= 0)
      body.append(
        facts("Right now", [
          ["Height", km(l.altKm)],
          ["Speed", `${l.speedKms.toFixed(2)} km/s · ${(Math.round(l.speedKms * 36) * 100).toLocaleString("en-US")} km/h`],
          ["Distance from you", km(l.rangeKm)],
          ["Light", l.sunlit ? "In sunlight" : "In Earth’s shadow"],
          ["Where", `${K.headline(l)}`],
        ]),
      );
    else body.append(facts("Right now", [["Where", "Below your horizon"]]));
    if (train) {
      const alts = train.members.map((m) => O.look(m, place.ob, t)).filter(Boolean).map((m) => m.altKm);
      body.append(
        facts("Train", [
          ["Satellites in the line", `${train.members.length} of ${train.batch} from this launch`],
          ["Launched", train.launch ? `${train.launch} · ${d.since < 1 ? "today" : d.since + " days ago"}` : null],
          ["Launch", train.intdes],
          ["Height", alts.length ? `${Math.round(Math.min(...alts)).toLocaleString("en-US")}–${km(Math.max(...alts))}` : null],
        ]),
      );
      body.append(
        element(
          "p",
          `Freshly launched ${train.family} satellites fly close together, like a string of lights, until they raise their orbits and spread out over days to weeks. Early orbit data for a batch is rough, so the real line can run ahead of or behind the drawing.`,
          "note",
        ),
      );
      const next = element("p", "Working out the next member above you…", "note");
      body.append(next);
      nextTrainPass(train, t, () => infoTarget === o && generation === infoGeneration,
        p => { next.textContent = trainRiseText(p); });
      wikiSection = element("section");
      body.append(wikiSection);
      $("wiki").hidden = false;
      $("wiki").disabled = false;
      $("wiki").textContent = "Read on Wikipedia";
      $("info-dialog").showModal();
      return;
    }
    body.append(
      facts("Orbit", [
        ["Circles Earth every", c && c.period ? C.period(c.period) : null],
        ["Height range", c && c.perigee != null && c.apogee != null ? `${c.perigee}–${c.apogee} km` : null],
        found.d.geo === "parked"
          ? ["Parked above", C.lonText(O.subLon(o, t)) ? `${C.lonText(O.subLon(o, t))} near the equator` : null]
          : [
              "Next time above you",
              p ? `${day(p.riseMs)} · up to ${K.height(p.maxEl)}${found.layer ? "" : ` · ${p.visible ? "visible" : "not visible"}`}` : "Not in the next 36 hours",
            ],
        ["Orbit data from", day(o.epoch)],
      ]),
    );
    body.append(
      facts("Catalog", [
        ["Name in the catalog", o.name],
        ["Type", d.kind],
        ["Launched", c && c.launch ? `${c.launch} · ${C.years(c.launch, t)} in orbit` : null],
        ["Radar size", c ? C.rcsWords(c.rcs) : null],
        ["IDs", `NORAD ${o.id}${o.intdes ? " · " + o.intdes : ""}`],
      ]),
    );
    const launch = element("section");
    body.append(launch);
    wikiSection = element("section");
    body.append(wikiSection);
    $("wiki").hidden = !C.wikiUrl(d);
    $("wiki").disabled = false;
    $("wiki").textContent = "Read on Wikipedia";
    $("info-dialog").showModal();
    loadLaunch(o, launch, generation);
  }
  async function loadLaunch(o, section, generation) {
    const url = C.launchUrl(o.intdes);
    if (!url) return;
    let rows = launches.get(o.intdes.slice(0, 8));
    if (!rows) {
      section.append(element("p", "Looking up the rest of its launch…", "note"));
      try {
        const r = await getJson(url);
        if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
        rows = C.parseSatcat(r.text);
        if (!rows.length) throw new Error("No usable launch records");
        launches.set(o.intdes.slice(0, 8), rows);
      } catch (_) {
        if (infoTarget === o && generation === infoGeneration) section.replaceChildren(element("p", "Launch details unavailable right now.", "note"));
        return;
      }
    }
    if (infoTarget !== o || generation !== infoGeneration) return;
    const v = C.summarizeLaunch(rows, o.id);
    section.replaceChildren(element("h3", "Same launch"));
    if (!v.total) return section.append(element("p", "Nothing else is catalogued from this launch.", "note"));
    if (v.payloads.length)
      section.append(
        element(
          "p",
          `${info(o).title.includes("rocket stage") ? "Carried" : "Launched with"}: ${v.payloads.map((x) => x.name).join(", ")}.`,
        ),
      );
    const bits = [];
    if (v.stages) bits.push(`${v.stages} other rocket stage${v.stages > 1 ? "s" : ""}`);
    if (v.debris) bits.push(`${v.debris} catalogued piece${v.debris > 1 ? "s" : ""} of debris`);
    if (bits.length) section.append(element("p", `Also from this launch: ${bits.join(" and ")}.`, "note"));
    if (v.reentered)
      section.append(element("p", `${v.reentered} of these have already fallen back and burned up.`, "note"));
  }
  $("wiki").onclick = async () => {
    const o = infoTarget, generation = infoGeneration;
    if (!o || infoBusy || wikiDone) return;
    const selectedObject = find(selected);
    const d = selectedObject && (selectedObject.o === o || selectedObject.train?.members.includes(o)) ? selectedObject.d : info(o),
      section = wikiSection;
    infoBusy = true;
    $("wiki").disabled = true;
    section.replaceChildren(element("h3", "Wikipedia"), element("p", "Asking Wikipedia…", "note"));
    let result = null,
      searched = false;
    try {
      for (const search of d.wiki ? [false, true] : [true]) {
        const url = C.wikiUrl(d, search);
        if (!url) continue;
        const r = await getJson(url);
        if (r.status !== 200) throw new Error(`Wikipedia unavailable (HTTP ${r.status}).`);
        result = C.parseWiki(r.text);
        searched = search;
        if (result) break;
      }
      if (infoTarget !== o || generation !== infoGeneration) return;
      section.replaceChildren(element("h3", "Wikipedia"));
      if (!result) section.append(element("p", "No Wikipedia article found for this object.", "note"));
      else {
        if (searched)
          section.append(element("p", `Closest match: ${result.title}. It may describe a related object.`, "note"));
        section.append(element("p", result.extract, "wiki-text"));
        section.append(
          element("p", `From the Wikipedia article “${result.title}”, CC BY-SA 4.0.`, "credit"),
        );
      }
      wikiDone = true;
      $("wiki").textContent = "Wikipedia loaded";
    } catch (e) {
      if (infoTarget !== o || generation !== infoGeneration) return;
      section.replaceChildren(element("h3", "Wikipedia"), element("p", describeError(e), "note attention"));
      $("wiki").disabled = false;
    } finally {
      if (generation === infoGeneration) infoBusy = false;
    }
  };
  $("close-info").onclick = () => {
    infoTarget = null;
    infoGeneration++;
    infoBusy = false;
    $("info-dialog").close();
  };
  $("info-dialog").addEventListener("close", () => {
    if ($("info-dialog").open) return;
    infoTarget = null;
    infoGeneration++;
    infoBusy = false;
  });
  $("details").onclick = openInfo;
  $("clear").onclick = () => select(null);

  // ---- place: one foreground fix or typed coordinates; never stored ----
  function welcome(state, text = "", tone = "", retry = false) {
    const loc = state === "locating";
    $("welcome-title").textContent = loc ? "Finding your location…" : "Where are you watching from?";
    $("welcome-progress").hidden = !loc;
    $("welcome-text").hidden = loc;
    $("retry-location").hidden = !retry;
    message($("welcome-status"), text, tone);
  }
  function setPlace(lat, lon, source, accuracy) {
    const ob = O.observer(lat, lon, 0);
    if (!ob) return false;
    place = { lat, lon, source, ob, aob: K.observer(lat, lon, 0) };
    clearHeading();
    sky = { stars: null, starsAt: 0, bodies: null, bodiesAt: 0 };
    passes.clear();
    ends.clear();
    $("place-label").textContent =
      source === "location"
        ? `Your location${Number.isFinite(accuracy) ? ` · ±${accuracy < 1000 ? Math.round(accuracy) + " m" : (accuracy / 1000).toFixed(1) + " km"}` : ""} · stays on this phone`
        : `${Math.abs(lat).toFixed(2)}° ${lat >= 0 ? "N" : "S"}, ${Math.abs(lon).toFixed(2)}° ${lon >= 0 ? "E" : "W"}`;
    $("welcome").hidden = true;
    $("workspace").hidden = false;
    listKey = "";
    lastCounts = "";
    frame();
    refreshData();
    return true;
  }
  async function locate(from) {
    if (busy || !active) return false;
    const e = epoch,
      request = ++locationRequest;
    locating = busy = true;
    $("show-sky").disabled = false;
    if (from === "dialog") message($("area-status"), "Getting one location fix…");
    try {
      const l = await call("location.read", { op: "get" });
      if (e !== epoch || request !== locationRequest || !active) return false;
      if (!Number.isFinite(l.latitude) || !Number.isFinite(l.longitude))
        throw new Error("Location unavailable.");
      locating = busy = false;
      if (from !== "dialog" && $("area-dialog").open) {
        $("latitude").value = l.latitude.toFixed(4);
        $("longitude").value = l.longitude.toFixed(4);
        message($("area-status"), "Location ready. Tap Show sky.");
        welcome("choose");
        return false;
      }
      if ($("area-dialog").open) $("area-dialog").close();
      return setPlace(l.latitude, l.longitude, "location", l.accuracyM);
    } catch (error) {
      if (e !== epoch || request !== locationRequest) return false;
      if (from === "dialog") message($("area-status"), describeError(error), "attention");
      else if (denied(error))
        welcome(
          "choose",
          "Phone location isn’t enabled for this module, so pick a place below. Allow both location switches in Construct’s Module access to skip this step next time.",
        );
      else welcome("choose", describeError(error), "attention", true);
      return false;
    } finally {
      if (e === epoch && request === locationRequest) locating = busy = false;
    }
  }
  function discardLocation() {
    if (!locating) return;
    locationRequest++;
    locating = busy = false;
  }
  const parse = (v) => {
    const s = String(v).trim().replace(/[−–]/g, "-").replace(",", ".");
    return /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : NaN;
  };
  function showArea() {
    if (!active) return;
    if (place) {
      $("latitude").value = place.lat.toFixed(4);
      $("longitude").value = place.lon.toFixed(4);
    }
    $("start-with-location").checked = prefs.startWithLocation;
    message($("area-status"), "");
    $("area-dialog").showModal();
  }
  $("start").onclick = showArea;
  $("area").onclick = showArea;
  $("retry-location").onclick = () => {
    welcome("locating");
    locate("retry");
  };
  $("cancel-area").onclick = () => {
    discardLocation();
    $("area-dialog").close();
    if (!place && !busy) welcome("choose");
  };
  $("area-dialog").addEventListener("cancel", () => {
    discardLocation();
    if (!place) welcome("choose");
  });
  $("use-location").onclick = () => locate("dialog");
  $("start-with-location").onchange = () => {
    prefs.startWithLocation = $("start-with-location").checked;
    savePrefs();
  };
  $("area-form").onsubmit = (event) => {
    event.preventDefault();
    const lat = parse($("latitude").value),
      lon = parse($("longitude").value);
    if (!(lat >= -90 && lat <= 90) || !(lon >= -180 && lon <= 180)) {
      message($("area-status"), "Enter a latitude from −90 to 90 and a longitude from −180 to 180.", "attention");
      return;
    }
    discardLocation();
    $("area-dialog").close();
    setPlace(lat, lon, "manual");
  };

  // ---- controls ----
  // ---- follow mode: the dome turns with the phone (orientation.read, API 0.14) ----
  // Headings arrive as magnetic; WMM2025 declination for the chosen place makes
  // them true. Readings are smoothed along the circle. Nothing is stored.
  // Raising the phone like a camera switches to the pointing view (SpacePointer).
  const wrap360 = (x) => ((x % 360) + 360) % 360,
    wrap180 = (x) => ((((x + 180) % 360) + 360) % 360) - 180;
  function clearHeading(resetDome = true) {
    if (follow.expiry !== null) clearTimeout(follow.expiry);
    follow.expiry = null;
    follow.heading = null;
    follow.accuracy = null;
    follow.pose = null;
    follow.calibrate = false;
    follow.unavailable = false;
    follow.lastSample = 0;
    follow.attitude = null;
    if (resetDome) follow.pointing = false;
    if (dome && resetDome) dome.turn(0);
  }
  async function startFollow(retryUntil = 0) {
    if (!active || !place) return;
    clearHeading();
    const request = ++follow.request;
    follow.want = true;
    try {
      await call("orientation.read", { op: "watch", rateHz: 10 });
      if (request !== follow.request) return;
      if (!active || !follow.want) return;
      follow.on = true;
      message($("follow-status"), "Hold the phone flat for the dome, or raise it like a camera to point.");
    } catch (e) {
      if (request !== follow.request) return;
      // Menu visibility can be delivered before the window focus callback.
      // Only explicit menu return gets this bounded retry; terminal events,
      // a new pause or Follow off invalidate the request and cancel it.
      if (e.code === "RUN_PAUSED" && active && follow.want && Date.now() < retryUntil) {
        message($("follow-status"), "Waiting for the module to regain focus…");
        applyFollow(true);
        setTimeout(() => {
          if (request === follow.request && active && follow.want) startFollow(retryUntil);
        }, 100);
        return;
      }
      follow.on = follow.want = false;
      message(
        $("follow-status"),
        e.code === "CAPABILITY_DENIED"
          ? "Allow reading compass and tilt for Space Watch in Construct’s Module access, then tap Follow again."
          : e.code === "ORIENTATION_UNAVAILABLE"
            ? "This phone has no compass Space Watch can use."
            : describeError(e),
        "attention",
      );
    }
    applyFollow(true);
  }
  function stopFollow() {
    follow.request++;
    follow.on = follow.want = false;
    clearHeading();
    call("orientation.read", { op: "stop" }).catch(() => {});
    applyFollow();
  }
  function applyFollow(keepStatus = false) {
    $("follow").setAttribute("aria-pressed", String(follow.on));
    $("follow-status").hidden = !follow.on && !keepStatus;
    if (!follow.on) dome.turn(0);
    applyPointing();
    message($("follow-announcement"), keepStatus ? $("follow-status").textContent : "Follow off.", "sr-only");
    frame();
  }
  function renderFollow() {
    applyPointing();
    if (!follow.on) return;
    let text, tone = "";
    if (follow.unavailable)
      text = "True-north correction unavailable for this place or date. The sky stays north-up; Follow guidance is paused.";
    else if (follow.pointing && follow.attitude) {
      const a = SpacePointer.aim(follow.attitude);
      text = `Pointing ${K.dir8(a.az)}, ${a.el < 0 ? "below the horizon" : K.height(a.el)}${follow.accuracy !== null ? ` · compass ±${Math.round(follow.accuracy)}°` : ""}`;
    } else if (follow.heading === null)
      text = follow.pointing
        ? "Waiting for the compass…"
        : follow.pose === "upright"
          ? "Raise the phone like a camera to point, or hold it flat for the dome."
          : "Waiting for the compass…";
    else {
      text = `Facing ${K.dir8(follow.heading)}${follow.accuracy !== null ? ` · compass ±${Math.round(follow.accuracy)}°` : ""}${follow.trueNorth ? "" : " · magnetic north"}`;
    }
    if (follow.calibrate) {
      text += ". Wave the phone in a figure 8 to calibrate the compass.";
      tone = "attention";
    }
    message($("follow-status"), text, tone);
    if (follow.calibrate) message($("follow-announcement"), "Wave the phone in a figure 8 to calibrate the compass.", "sr-only");
    else if (!follow.pointing) message($("follow-announcement"), follow.heading !== null ? "Follow active. Compass direction and turn guidance are available below." : text, "sr-only");
  }
  // ---- pointing view: the phone raised like a camera ----
  let pointer = null,
    pointGuide = null;
  function applyPointing() {
    const on = follow.on && follow.pointing && !follow.unavailable;
    $("pointer-wrap").hidden = !on;
    $("dome").hidden = on;
    $("scrub").hidden = on;
    if (!on) pointGuide = null;
  }
  // The selected object, if it is above the horizon now, with its track
  // (recomputed every two seconds; the dot itself moves with every reading).
  let pointTrack = { id: null, t: 0, points: null };
  function pointTarget(t) {
    if (selected === null || offset !== 0) return null;
    const found = find(selected, t),
      l = found && O.look(found.o, place.ob, t);
    if (!l || l.el < 0) return null;
    if (pointTrack.id !== selected || Math.abs(t - pointTrack.t) > 2000)
      pointTrack = { id: selected, t, points: O.trail(found.o, place.ob, t) };
    return { az: l.az, el: l.el, label: shortLabel(found.o, found.d), track: pointTrack.points };
  }
  // Something bright near the middle of the view, to name what the phone points at.
  function centred(a) {
    let best = null;
    const near = (x, name) => {
      const sep = SpacePointer.separation(a, x);
      if (sep <= 6 && (!best || sep < best.sep)) best = { sep, name, id: x.id };
    };
    for (const x of lastSky ? lastSky.items : [])
      if (x.state === "visible") near(x.l, shortLabel(x.o, x.d));
    for (const b of sky.bodies || []) if (b.el > 0) near(b, b.label);
    for (const st of sky.stars || []) if (st.name && st.mag < 2 && st.el > 0) near(st, st.name);
    return best;
  }
  function renderPoint() {
    if (!follow.on || !follow.pointing || follow.unavailable || !place || !active) return;
    const f = follow.attitude,
      t = now(),
      target = f ? pointTarget(t) : null,
      g = target ? SpacePointer.guide(f, target) : null;
    let text;
    if (!f) text = "Waiting for the compass…";
    else if (g) text = g.text;
    else {
      const c = centred(SpacePointer.aim(f));
      text = selected !== null
        ? "The selected object is below your horizon now."
        : c ? `In the middle: ${c.name}. Tap a satellite in the list to be guided to it.` : "Tap a satellite in the list to be guided to it.";
    }
    message($("point-guide"), text, g && g.locked ? "locked" : "");
    // Announce only when the kind of guidance changes, not every few degrees.
    const key = g ? g.key : text;
    if (!pointGuide || pointGuide.key !== key || pointGuide.calibrate !== follow.calibrate) {
      pointGuide = { key, text, calibrate: follow.calibrate };
      if (!follow.calibrate) message($("follow-announcement"), g ? g.short : text, "sr-only");
    }
    pointer.draw({
      frame: f,
      target,
      guide: g,
      stars: sky.stars,
      bodies: sky.bodies,
      objects: lastSky
        ? [...lastSky.items, ...(lastSky.layers || [])].filter((x) => x.id !== selected).map((x) => ({ az: x.l.az, el: x.l.el, state: x.state }))
        : [],
      palette: SpaceDome.palette(prefs.red),
      dark: lastSky ? lastSky.sunAlt < O.DARK_SUN : true,
    });
  }
  // "Ahead of you", or which way to turn, for the selected object.
  function renderTurn() {
    const el = $("spot-turn");
    if (!follow.on || follow.pointing || follow.heading === null || spotAz === null) {
      el.hidden = true;
      return;
    }
    const d = wrap180(spotAz - follow.heading),
      a = Math.abs(d);
    el.hidden = false;
    const text =
      a <= 28
        ? `Ahead of you${a > 8 ? `, slightly ${d > 0 ? "right" : "left"}` : ""}.`
        : a >= 150
          ? "Behind you: turn around."
          : `Turn ${d > 0 ? "right" : "left"} about ${Math.round(a / 10) * 10}°.`;
    if (el.textContent !== text) el.textContent = text;
  }
  window.addEventListener("constructorientation", (event) => {
    const s = event.detail || {};
    if (s.watching === false && follow.want) {
      // The host ended the stream (another screen in front, or access revoked).
      follow.request++;
      follow.on = follow.want = false;
      clearHeading();
      message(
        $("follow-status"),
        s.reason === "revoked"
          ? "Compass access was turned off in Module access. Follow is off."
          : "Follow stopped when Space Watch lost the foreground (notifications, Quick Settings or another app). Tap Follow to turn it back on.",
        "attention",
      );
      applyFollow(true);
      return;
    }
    if (!follow.on || !active || !place) return;
    const sampleAge = Date.now() - s.timestamp;
    if (!Number.isFinite(s.timestamp) || sampleAge < 0 || sampleAge > 1500) {
      const changed = follow.heading !== null || follow.unavailable;
      clearHeading();
      if (changed) frame();
      renderFollow(); renderTurn();
      return;
    }
    const fresh = Date.now() - follow.lastSample <= 1500,
      previous = fresh ? follow.heading : null,
      previousAttitude = fresh ? follow.attitude : null,
      wasPointing = follow.pointing,
      wasUnavailable = follow.unavailable;
    clearHeading(false);
    follow.pose = s.pose === "flat" ? "flat" : "upright";
    follow.calibrate = s.calibrate === true;
    follow.accuracy = Number.isFinite(s.accuracyDeg) ? s.accuracyDeg : null;
    // Camera axis above about −25° (pitch < 25) means the phone is raised to
    // point; a margin keeps the view from flickering at the threshold.
    follow.pointing = Number.isFinite(s.pitchDeg) && s.pitchDeg < (wasPointing ? 35 : 25);
    // Pointing is always about the sky now: leave rewind and pass previews.
    const leftPreview = follow.pointing && offset !== 0;
    if (leftPreview) {
      selectedPass = null;
      offset = 0;
      $("rewind").value = "0";
      listKey = "";
    }
    if ((follow.pose === "flat" || follow.pointing) && Number.isFinite(s.azimuthDeg)) {
      const dec = SpaceMagnetic.declination(place.lat, place.lon, now());
      follow.trueNorth = dec !== null;
      follow.unavailable = dec === null;
      if (dec === null) {
        dome.turn(0);
        if (!wasUnavailable) frame();
        renderFollow(); renderTurn();
        return;
      }
      const heading = wrap360(s.azimuthDeg + dec);
      if (follow.pointing) {
        // The bearing is the camera axis when upright, the screen's top edge when flat.
        const next = SpacePointer.orient({ pitchDeg: s.pitchDeg, rollDeg: s.rollDeg, bearingDeg: heading, axis: follow.pose === "upright" ? "camera" : "top" });
        follow.attitude = next && SpacePointer.smooth(previousAttitude, next, 0.35);
      } else {
        const first = previous === null;
        // A quarter of the way toward each reading, along the shorter way round.
        follow.heading = first ? heading : wrap360(previous + 0.25 * wrap180(heading - previous));
      }
      follow.lastSample = s.timestamp;
      const measuredAt = s.timestamp;
      follow.expiry = setTimeout(() => {
        if (!follow.on || follow.lastSample !== measuredAt) return;
        clearHeading();
        frame(); renderFollow(); renderTurn();
      }, Math.max(1, 1501 - sampleAge));
      if (follow.heading !== null) dome.turn(follow.heading);
    }
    if (follow.heading === null && follow.pose !== "upright") dome.turn(0);
    // Refresh wedge/spot validity on pose and reliability transitions only.
    if ((previous === null) !== (follow.heading === null) || follow.pointing !== wasPointing || leftPreview) frame();
    renderFollow();
    renderTurn();
    renderPoint();
  });
  $("follow").onclick = () => (follow.want ? stopFollow() : startFollow());
  function applyRed() {
    document.body.classList.toggle("red", prefs.red);
    $("red").setAttribute("aria-pressed", String(prefs.red));
  }
  $("red").onclick = () => {
    prefs.red = !prefs.red;
    applyRed();
    savePrefs();
    frame();
  };
  $("rewind").oninput = () => {
    selectedPass = null;
    const v = Number($("rewind").value);
    offset = Number.isFinite(v) ? Math.max(-300, Math.min(0, Math.round(v))) : 0;
    listKey = "";
    frame();
  };
  $("now").onclick = () => {
    selectedPass = null;
    offset = 0;
    $("rewind").value = "0";
    listKey = "";
    frame();
  };
  $("refresh").onclick = () => refreshData(true);
  dome = new SpaceDome($("dome"), (id) => select(id));
  pointer = new SpacePointer.View($("pointer"));

  window.addEventListener("constructvisibilitychange", (event) => {
    active = event.detail?.visible !== false;
    epoch++;
    if (!active) {
      follow.request++;
      follow.on = false;
      clearHeading();
      $("follow").setAttribute("aria-pressed", "false");
      discardLocation();
      infoBusy = false;
      if ($("info-dialog").open) {
        $("info-dialog").close();
        infoTarget = null;
        infoGeneration++;
      }
      message($("status"), "Paused while Construct’s menu is open.");
      if (!place) welcome("choose");
      return;
    }
    message($("status"), "");
    // The host ends the compass stream on pause; ask again on return.
    if (follow.want) {
      follow.on = false;
      follow.heading = null;
      startFollow(Date.now() + 2000);
    }
    frame();
    refreshData();
  });
  let ticks = 0;
  setInterval(() => {
    if (!active || !place) return;
    frame();
    planStep();
    if (++ticks % 60 === 0) {
      rebuildTrains();
      refreshData();
    }
  }, 1000);
  (async () => {
    await ready;
    if (!active) return;
    if (prefs.startWithLocation && !place) {
      welcome("locating", "One foreground fix, used only on this phone. Choose place to enter coordinates instead.");
      await locate("start");
    } else welcome("choose");
  })();
})();
