"use strict";
// Aimé module logic without DOM or host calls: per-photo sidecars keyed by the
// API 0.12 stable photo id, capture association, orphan reconciliation, the
// landmark cells (aime-data contract, schema 1), local name search and the
// candidates shortlist.
// Global `AimeCore` in the module, CommonJS under Node for scripts/test_aime.cjs.
const AimeCore = (() => {
  const RADII = [10, 30, 60],
    DEFAULT_RADIUS = 30,
    MAX_MARKS = 6,
    MAX_HORIZON = 2,
    NAME_MAX = 80,
    // Landmark cells: index once per session, then the 1° cells a radius touches.
    DATA_ORIGIN = "https://aime-data.pages.dev",
    INDEX_URL = DATA_ORIGIN + "/v1/index.json",
    // The host runs at most four requests per module; the map's tile loader
    // keeps up to two in flight, so landmark downloads use the other two.
    DATA_CONCURRENCY = 2,
    // A fix older than the host's own cache limit, or a viewfinder wait longer
    // than this, may no longer be where the photo was taken.
    OLD_FIX_MS = 120000,
    LONG_WAIT_MS = 60000,
    LOCATION_SPACING_MS = 15000,
    // Persistence: one bounded record per photo in a fixed pool of slots plus a
    // small index. Every storage.kv request must fit the host's 8,192-character
    // bridge message; the host also keeps keys set to null, so keys are reused
    // slots, never derived from ever-new photo ids.
    MAX_SLOTS = 16,
    INDEX_KEY = "photos.index",
    MESSAGE_LIMIT = 8192,
    MESSAGE_BUDGET = 7600;
  const num = (x) => typeof x === "number" && Number.isFinite(x);
  // Control/format characters are dropped: they carry no name and would expand
  // the storage request when escaped.
  const text = (s, max = NAME_MAX) => (typeof s === "string" ? s.replace(/[\p{Cc}\p{Cf}\p{Cs}]/gu, "").trim().slice(0, max) : "");
  const inUnit = (v) => num(v) && v >= 0 && v <= 1;
  const latLon = (lat, lon) => num(lat) && num(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180;
  const OSM_TYPES = ["node", "way", "relation"];
  const isKind = (k) => typeof k === "string" && /^[a-z][a-z_]{0,39}$/.test(k),
    isRelease = (r) => typeof r === "string" && /^[\w.-]{1,40}$/.test(r),
    // Position uncertainty per feature (contract `p`): integer metres, 5–1000.
    isP = (p) => Number.isInteger(p) && p >= 5 && p <= 1000;

  // ---- Sidecars -------------------------------------------------------------
  // Shape (brief): { viewer: {lat, lon, accuracyM, timestamp, approximate, corrected,
  // review}, radiusKm, marks: [{x, y, kind, name, lat, lon, positionM, dataset}],
  // horizon: [{x, y}] }. `review` (not in the brief's list) marks a viewpoint that
  // must be confirmed or corrected before any feature query.
  function cleanViewer(v) {
    if (!v || !latLon(v.lat, v.lon)) return null;
    return {
      lat: v.lat,
      lon: v.lon,
      accuracyM: num(v.accuracyM) && v.accuracyM > 0 ? Math.min(v.accuracyM, 50000) : null,
      timestamp: num(v.timestamp) ? v.timestamp : null,
      approximate: v.approximate === true,
      corrected: v.corrected === true,
      review: v.review === true,
    };
  }
  // Marks saved before landmark cells (Aimé ≤ 0.1.2) carry an OSM type and id
  // instead of kind and dataset. They keep that shape, name, position and
  // estimate, so they load, calibrate and round-trip unchanged.
  function cleanMark(m) {
    if (!m || !inUnit(m.x) || !inUnit(m.y) || !latLon(m.lat, m.lon)) return null;
    if (isKind(m.kind))
      return {
        x: m.x,
        y: m.y,
        kind: m.kind,
        name: text(m.name) || "Landmark",
        lat: m.lat,
        lon: m.lon,
        positionM: num(m.positionM) && m.positionM > 0 ? m.positionM : 30,
        dataset: isRelease(m.dataset) ? m.dataset : "",
      };
    if (!OSM_TYPES.includes(m.osmType) || !Number.isSafeInteger(m.osmId)) return null;
    return {
      x: m.x,
      y: m.y,
      osmType: m.osmType,
      osmId: m.osmId,
      name: text(m.name) || m.osmType + "/" + m.osmId,
      lat: m.lat,
      lon: m.lon,
      // Keep the stored estimate (30 m for way/relation centres) on reopen.
      positionM: num(m.positionM) && m.positionM > 0 ? m.positionM : m.osmType === "node" ? 8 : 30,
    };
  }
  function cleanSidecar(raw) {
    if (!raw || typeof raw !== "object") return null;
    return {
      viewer: cleanViewer(raw.viewer),
      radiusKm: RADII.includes(raw.radiusKm) ? raw.radiusKm : DEFAULT_RADIUS,
      marks: (Array.isArray(raw.marks) ? raw.marks : []).map(cleanMark).filter(Boolean).slice(0, MAX_MARKS),
      horizon: (Array.isArray(raw.horizon) ? raw.horizon : [])
        .filter((h) => h && inUnit(h.x) && inUnit(h.y))
        .map((h) => ({ x: h.x, y: h.y }))
        .slice(0, MAX_HORIZON),
    };
  }
  const validId = (id) => typeof id === "string" && /^[\x21-\x7e]{1,80}$/.test(id);
  // ---- Persistence plan (pure; the controller performs the storage calls) ----
  const recordKey = (slot) => "photo." + slot;
  // Index value → slots array (id or null). Invalid or duplicate ids are dropped.
  function loadIndex(raw) {
    const slots = Array(MAX_SLOTS).fill(null),
      seen = new Set();
    const list = raw && typeof raw === "object" && raw.v === 1 && Array.isArray(raw.slots) ? raw.slots : [];
    list.slice(0, MAX_SLOTS).forEach((id, i) => {
      if (validId(id) && !seen.has(id)) {
        seen.add(id);
        slots[i] = id;
      }
    });
    return slots;
  }
  const indexValue = (slots) => ({ v: 1, slots: slots.slice() });
  // A record counts only when it names the id its slot is claimed for.
  const recordValue = (id, sidecar) => ({ id, sidecar });
  const recordFor = (raw, id) => (raw && typeof raw === "object" && raw.id === id ? cleanSidecar(raw.sidecar) : null);
  // Where to write `id`: its slot, or the first free one (claim → index write).
  function planPut(slots, id) {
    const own = slots.indexOf(id);
    if (own >= 0) return { slot: own, claim: false, slots };
    const free = slots.indexOf(null);
    if (free < 0) throw Object.assign(new Error("Aimé's photo records are full. Delete a photo, then reopen Aimé."), { code: "STORAGE_FULL" });
    const next = slots.slice();
    next[free] = id;
    return { slot: free, claim: true, slots: next };
  }
  // Free every slot whose id is not in `keepIds` (one index write).
  function planRelease(slots, keepIds) {
    const keep = new Set(keepIds),
      freed = [],
      next = slots.map((id, i) => (id !== null && !keep.has(id) ? (freed.push({ slot: i, id }), null) : id));
    return { slots: next, freed };
  }
  // Length of the bridge message a set request produces (ids up to 8 digits).
  const envelopeLength = (key, value) => JSON.stringify({ id: "99999999", method: "storage.kv", params: { op: "set", key, value } }).length;
  function checkEnvelope(key, value) {
    if (envelopeLength(key, value) > MESSAGE_BUDGET)
      throw Object.assign(new Error("This photo's data is too large to save. Remove a mark and try again."), { code: "STORAGE_SIZE" });
  }
  // Persistence over storage.kv-like {get(key), set(key, value)} promises. The
  // in-memory copy changes only after the storage writes it depends on succeed.
  function persistence(kv) {
    let slots = null,
      store = null;
    const set = async (key, value) => {
      checkEnvelope(key, value);
      await kv.set(key, value);
    };
    const unavailable = () => Object.assign(new Error("Storage access is off, so viewpoints and marks cannot be saved."), { code: "STORAGE_UNAVAILABLE" });
    return {
      get store() {
        return store;
      },
      get slots() {
        return slots;
      },
      // Any failed read leaves storage unavailable: never an empty store that a
      // later write could overwrite.
      async load() {
        try {
          const nextSlots = loadIndex(await kv.get(INDEX_KEY)),
            next = {};
          for (let slot = 0; slot < nextSlots.length; slot++) {
            if (!nextSlots[slot]) continue;
            const sidecar = recordFor(await kv.get(recordKey(slot)), nextSlots[slot]);
            if (sidecar) next[nextSlots[slot]] = sidecar;
          }
          slots = nextSlots;
          store = next;
          return null;
        } catch (error) {
          slots = null;
          store = null;
          return error;
        }
      },
      // Record first, then claim the slot: an interrupted claim leaves the slot
      // free and the next attempt rewrites it.
      async put(id, sidecar) {
        if (!store) throw unavailable();
        const clean = cleanSidecar(sidecar),
          plan = planPut(slots, id);
        await set(recordKey(plan.slot), recordValue(id, clean));
        if (plan.claim) await set(INDEX_KEY, indexValue(plan.slots));
        slots = plan.slots;
        store = { ...store, [id]: clean };
      },
      // Only after a successful complete list or a confirmed delete: free the
      // slots of photos that are gone in one index write, then clear records.
      async release(keepIds) {
        if (!store) return [];
        const plan = planRelease(slots, keepIds);
        if (!plan.freed.length) return [];
        await set(INDEX_KEY, indexValue(plan.slots));
        slots = plan.slots;
        const next = { ...store };
        for (const { id } of plan.freed) delete next[id];
        store = next;
        // Unclaimed records are ignored on load; clearing them only returns bytes.
        for (const { slot } of plan.freed) await set(recordKey(slot), null).catch(() => {});
        return plan.freed.map((f) => f.id);
      },
    };
  }
  function newSidecar(viewer, radiusKm = DEFAULT_RADIUS) {
    return cleanSidecar({ viewer, radiusKm, marks: [], horizon: [] });
  }
  // Library list → ids. Throws when the list is not the API 0.12 shape, so a
  // missing id is never treated as an empty or partial library.
  function listIds(result) {
    if (!result || !Array.isArray(result.photos)) throw Object.assign(new Error("Unexpected photo list."), { code: "PHOTO_LIST" });
    const ids = result.photos.map((p) => p && p.id);
    if (!ids.every(validId) || new Set(ids).size !== ids.length)
      throw Object.assign(new Error("This Construct version does not provide stable photo IDs. Update Construct."), { code: "PHOTO_IDS" });
    return ids;
  }
  // Exactly one new id between two successful complete lists, else null.
  function associate(beforeIds, afterIds) {
    const before = new Set(beforeIds),
      fresh = afterIds.filter((id) => !before.has(id));
    return fresh.length === 1 ? fresh[0] : null;
  }

  // ---- Viewpoint from before/after fixes ----------------------------------
  // location.read result → viewer candidate, or null when unusable.
  function fixFrom(result) {
    if (!result || !latLon(result.latitude, result.longitude) || !num(result.timestamp)) return null;
    return {
      lat: result.latitude,
      lon: result.longitude,
      accuracyM: num(result.accuracyM) && result.accuracyM > 0 ? result.accuracyM : null,
      timestamp: result.timestamp,
      approximate: result.approximate === true,
    };
  }
  function metres(a, b) {
    const rad = Math.PI / 180,
      h = Math.sin(((b.lat - a.lat) * rad) / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(((b.lon - a.lon) * rad) / 2) ** 2;
    return 2 * 6371008.8 * Math.asin(Math.sqrt(Math.min(1, h)));
  }
  // Keep the later fix by its own timestamp (not request order). Flag review when
  // the fixes disagree beyond their combined accuracy, the kept fix is old at
  // capture, or the viewfinder stayed open long enough to walk somewhere else.
  function chooseViewpoint(before, after, openedAt, savedAt) {
    const fixes = [before, after].filter(Boolean);
    if (!fixes.length) return null;
    const kept = fixes.reduce((a, b) => (b.timestamp > a.timestamp ? b : a));
    const reasons = [];
    if (before && after) {
      const apart = metres(before, after),
        allowed = (before.accuracyM || 20) + (after.accuracyM || 20);
      if (apart > allowed) reasons.push("fixes disagree");
    }
    if (num(savedAt) && savedAt - kept.timestamp > OLD_FIX_MS) reasons.push("old fix");
    if (num(openedAt) && num(savedAt) && savedAt - openedAt > LONG_WAIT_MS) reasons.push("long viewfinder wait");
    return { viewer: cleanViewer({ ...kept, corrected: false, review: reasons.length > 0 }), reasons };
  }
  // A viewpoint that may be used for a landmark lookup.
  const queryable = (viewer) => !!viewer && !viewer.review;

  // ---- Landmark cells (aime-data contract, schema 1) -----------------------
  const dataError = (code, message, retry = true) => Object.assign(new Error(message), { code, retry });
  const unavailable = (reason) => dataError("DATA_INVALID", "Landmark data unavailable: " + reason + " Retry later.");
  const readJson = (body, what) => {
    try {
      return JSON.parse(body);
    } catch {
      throw unavailable(what + " is unreadable.");
    }
  };
  const CELL = /^(-?\d{1,2})_(-?\d{1,3})$/;
  const validCell = (value) => {
    const m = typeof value === "string" && value.match(CELL);
    return !!m && +m[1] >= -90 && +m[1] < 90 && +m[2] >= -180 && +m[2] < 180 && value === `${+m[1]}_${+m[2]}`;
  };
  // 1° cells (integer south-west corner) of the radius's bounding box. The
  // longitude half-width is the spherical cap's, asin(sin δ / cos φ); a cap
  // over a pole spans every longitude.
  function cellsAround(lat, lon, radiusKm) {
    if (!latLon(lat, lon) || !RADII.includes(radiusKm)) throw new Error("Viewpoint and a 10/30/60 km radius are required.");
    const deg = 180 / Math.PI,
      d = radiusKm / 6371.0088,
      dLat = d * deg,
      s = Math.sin(d) / Math.cos(lat / deg),
      dLon = lat + dLat >= 90 || lat - dLat <= -90 || s >= 1 ? 180 : Math.asin(s) * deg,
      lon0 = Math.floor(lon - dLon),
      lon1 = Math.min(Math.floor(lon + dLon), lon0 + 359),
      out = new Set();
    for (let a = Math.max(-90, Math.floor(lat - dLat)); a <= Math.min(89, Math.floor(lat + dLat)); a++)
      for (let o = lon0; o <= lon1; o++) out.add(a + "_" + ((((o + 180) % 360) + 360) % 360 - 180));
    return [...out];
  }
  // index.json text → {release, revision, dataset, path, cells (Set), kinds (Set),
  // coverage, license, attribution}. Anything but schema 1 in the expected shape
  // is unavailable. Kinds only validate records; they carry no position values.
  function parseIndex(body) {
    const x = readJson(body, "The landmark index");
    if (!x || x.schema !== 1) throw unavailable("the landmark index has an unsupported schema.");
    const kinds = new Set(Array.isArray(x.kinds) ? x.kinds.filter(isKind) : []);
    // dataset = <release>-r<revision>; its cells live under <dataset>/cells/.
    const dataset = isRelease(x.release) && Number.isInteger(x.revision) && x.revision >= 1 ? `${x.release}-r${x.revision}` : null;
    if (!dataset || x.dataset !== dataset || !isRelease(x.dataset) || x.path !== dataset + "/cells/" || !Array.isArray(x.cells) || !x.cells.every(validCell) || !kinds.size)
      throw unavailable("the landmark index is incomplete.");
    return {
      release: x.release,
      revision: x.revision,
      dataset,
      path: x.path,
      cells: new Set(x.cells),
      kinds,
      coverage: Array.isArray(x.coverage) ? x.coverage.filter((c) => typeof c === "string") : [],
      license: text(x.license, 40) || "ODbL-1.0",
      attribution: text(x.attribution, 120) || "© OpenStreetMap contributors, Overture Maps Foundation",
    };
  }
  const cellUrl = (index, cell) => DATA_ORIGIN + "/v1/" + index.path + cell + ".json";
  // Session cache key: a revision of the same release is a different dataset.
  const cellKey = (index, cell) => index.dataset + "/" + cell;
  // Cells to download for a viewpoint and radius: only those the index lists.
  const cellPlan = (index, viewer, radiusKm) => cellsAround(viewer.lat, viewer.lon, radiusKm).filter((c) => index.cells.has(c));
  const TERRAIN = new Set(["peak", "hill", "volcano"]);
  // Cell text → features. A cell whose schema, release, revision or corner does
  // not match the index, or without a feature array, is unavailable (never
  // empty). Missing or invalid position uncertainty makes the entire cell
  // unavailable: never cache incomplete data as a successful empty lookup.
  // `p` is the feature's positionM, with no kind-level fallback.
  function parseCell(index, cell, body) {
    const x = readJson(body, "Landmark cell " + cell),
      m = cell.match(CELL);
    if (!x || x.schema !== 1 || x.release !== index.release || x.revision !== index.revision) throw unavailable(`landmark cell ${cell} does not match the index dataset (release and revision).`);
    if (!m || !Array.isArray(x.cell) || x.cell.length !== 2 || x.cell[0] !== Number(m[1]) || x.cell[1] !== Number(m[2]) || !Array.isArray(x.f)) throw unavailable(`landmark cell ${cell} is malformed.`);
    const features = [];
    for (const r of x.f) {
      if (!Array.isArray(r) || !isP(r[6])) throw unavailable(`landmark cell ${cell} contains invalid position uncertainty.`);
      if (!Array.isArray(r) || r.length !== 7 || typeof r[0] !== "string" || !index.kinds.has(r[1]) || !latLon(r[2], r[3]) || !isP(r[6])) continue;
      const name = text(r[0]);
      if (!name) continue;
      const f = { name, kind: r[1], lat: r[2], lon: r[3], e: num(r[4]) ? r[4] : 0, w: num(r[5]) ? Math.min(2, Math.max(0.5, r[5])) : 1, p: r[6], positionM: r[6], dataset: index.dataset };
      // Peaks may count beyond the solver's default 40 km.
      if (TERRAIN.has(f.kind)) f.maxKm = 100;
      features.push(f);
    }
    return features;
  }
  // Identity of a landmark: name, kind and position to 5 decimals (no OSM ids).
  const featureKey = (f) => [f.name, f.kind || "", f.lat.toFixed(5), f.lon.toFixed(5)].join("|");
  const sameFeature = (a, b) => {
    if (featureKey(a) === featureKey(b)) return true;
    // Old OSM marks have no kind. Reselecting the same named position replaces
    // its observation rather than giving the solver duplicate evidence.
    const legacy = (f) => !f.kind && ["node", "way", "relation"].includes(f.osmType) && Number.isInteger(f.osmId);
    return (legacy(a) || legacy(b)) && a.name === b.name && a.lat.toFixed(5) === b.lat.toFixed(5) && a.lon.toFixed(5) === b.lon.toFixed(5);
  };
  const coverageNote = (data) => data.partialCoverage ? "Partial coverage: some search-area cells are outside this dataset; landmarks may be missing." : "";
  // Features of the downloaded cells within the radius, deduplicated.
  function within(features, viewer, radiusKm) {
    const seen = new Set();
    return features.filter((f) => metres(viewer, f) <= radiusKm * 1000 && !seen.has(featureKey(f)) && seen.add(featureKey(f)));
  }
  const cacheKey = (viewer, radiusKm) => viewer.lat.toFixed(5) + "," + viewer.lon.toFixed(5) + "," + radiusKm;
  const COUNTRIES = { DE: "Germany", AT: "Austria" };
  function outsideMessage(coverage) {
    const names = coverage.map((c) => COUNTRIES[c] || c);
    const list = names.length > 1 ? names.slice(0, -1).join(", ") + " and " + names[names.length - 1] : names[0];
    return "No landmark data here yet." + (list ? ` ${list} for now.` : "");
  }
  // net.http failures and statuses from the data host → one "unavailable" error
  // naming the gate. Only a denied grant has no retry.
  function httpProblem(error, status) {
    if (num(status)) return dataError("DATA_STATUS", `Landmark data unavailable: the data host answered HTTP ${status}. Retry later.`);
    const code = (error && error.code) || "HTTP_UNAVAILABLE";
    const messages = {
      CAPABILITY_DENIED: "Internet access is off for Aimé. Turn it on in Construct menu → Module access.",
      HTTP_SIZE: "the data host sent a file Construct could not accept (size).",
      SIZE_LIMIT: "the data host sent a file Construct could not accept (size).",
      HTTP_DATA: "the data host sent a file Construct could not accept (type or size).",
      HTTP_RATE: "too many requests from this module. Wait a minute, then retry.",
      HTTP_BUSY: "other requests are still running. Retry in a moment.",
      HTTP_UNAVAILABLE: "the data host could not be reached (offline or timed out). Retry when online.",
      TIMEOUT: "the data host did not answer in time. Retry.",
    };
    if (code === "CAPABILITY_DENIED") return dataError(code, messages[code], false);
    return dataError(code, "Landmark data unavailable: " + (messages[code] || (error && error.message) || "download failed."));
  }
  // At most `n` tasks at once, in call order.
  function limiter(n) {
    let active = 0;
    const queue = [];
    const next = () => {
      if (active >= n || !queue.length) return;
      active++;
      const { fn, resolve, reject } = queue.shift();
      Promise.resolve()
        .then(fn)
        .then(resolve, reject)
        .finally(() => {
          active--;
          next();
        });
    };
    return (fn) => new Promise((resolve, reject) => (queue.push({ fn, resolve, reject }), next()));
  }
  // Landmark data over get(url) → Promise<JSON text> (throws the errors above).
  // The index is fetched once per session and cells once per dataset and cell;
  // only successes are kept, so a retry downloads just what failed.
  function landmarkData(get, concurrency = DATA_CONCURRENCY) {
    const limit = limiter(concurrency),
      cells = new Map(),
      jobs = new Map();
    let index = null,
      indexJob = null;
    function loadIndex() {
      if (index) return Promise.resolve(index);
      if (!indexJob)
        indexJob = limit(() => get(INDEX_URL))
          .then(parseIndex)
          .then((i) => (index = i))
          .finally(() => (indexJob = null));
      return indexJob;
    }
    function cell(ix, name) {
      const key = cellKey(ix, name);
      if (cells.has(key)) return Promise.resolve(cells.get(key));
      if (!jobs.has(key))
        jobs.set(key, limit(() => get(cellUrl(ix, name)))
          .then((body) => {
            const f = parseCell(ix, name, body);
            cells.set(key, f);
            return f;
          })
          .finally(() => jobs.delete(key)));
      return jobs.get(key);
    }
    return {
      get index() {
        return index;
      },
      loadIndex,
      // → {features, dataset, cells}; outside coverage throws OUTSIDE_COVERAGE.
      async features(viewer, radiusKm) {
        const ix = await loadIndex(),
          plan = cellPlan(ix, viewer, radiusKm);
        if (!plan.length) throw dataError("OUTSIDE_COVERAGE", outsideMessage(ix.coverage), false);
        const lists = await Promise.all(plan.map((c) => cell(ix, c)));
        return { features: within(lists.flat(), viewer, radiusKm), dataset: ix.dataset, cells: plan.length,
          partialCoverage: plan.length < cellsAround(viewer.lat, viewer.lon, radiusKm).length };
      },
    };
  }

  // ---- Local name search --------------------------------------------------
  const fold = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  function search(features, query, viewer, limit = 30) {
    const q = fold(text(query, 120));
    const withDistance = (f) => ({ feature: f, distanceM: viewer ? metres(viewer, f) : null });
    const hits = features.filter((f) => !q || fold(f.name).includes(q));
    return hits
      .map(withDistance)
      .sort((a, b) => (a.distanceM ?? 0) - (b.distanceM ?? 0) || a.feature.name.localeCompare(b.feature.name))
      .slice(0, limit);
  }

  // ---- Calibration and shortlist ------------------------------------------
  function markFrom(feature, x, y) {
    return cleanMark({ x, y, kind: feature.kind, name: feature.name, lat: feature.lat, lon: feature.lon, positionM: feature.positionM, dataset: feature.dataset });
  }
  function calibrationInput(sidecar, width, height) {
    const v = sidecar.viewer;
    return {
      viewer: { lat: v.lat, lon: v.lon, accuracyM: v.accuracyM ?? undefined },
      marks: sidecar.marks.map((m) => ({ x: m.x, y: m.y, point: { lat: m.lat, lon: m.lon }, positionM: m.positionM })),
      horizon: sidecar.horizon.map((h) => ({ x: h.x, y: h.y })),
      width,
      height,
    };
  }
  const candidatesOf = (features) =>
    features.map((f) => ({ point: { lat: f.lat, lon: f.lon }, weight: f.w, maxKm: f.maxKm, positionM: f.positionM, feature: f }));
  // Ranked results → what the sheet shows. Up to five, best first. With no
  // `close` result: "no close match" and the two angularly nearest, greyed.
  function shortlist(ranked, max = 5) {
    const anyClose = ranked.some((r) => r.close);
    if (anyClose) return { anyClose, rows: ranked.slice(0, max).map((r) => ({ ...r, greyed: !r.close })) };
    const nearest = [...ranked].sort((a, b) => Math.abs(a.deltaDeg) - Math.abs(b.deltaDeg)).slice(0, 2);
    return { anyClose, rows: nearest.map((r) => ({ ...r, greyed: true })) };
  }
  // "close by, so your position matters more" when the comparison σ is much
  // wider than the direction σ.
  const positionMatters = (row) => row.sigmaDeg > 2 * row.wedgeSigmaDeg && row.sigmaDeg - row.wedgeSigmaDeg > 2;

  // ---- Formatting ---------------------------------------------------------
  const COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  const compass = (deg) => COMPASS[Math.round((((deg % 360) + 360) % 360) / 22.5) % 16];
  const km = (d) => (d < 1 ? Math.round(d * 1000) + " m" : d < 10 ? d.toFixed(1) + " km" : Math.round(d) + " km");
  const signed = (d) => (d >= 0 ? "+" : "−") + Math.abs(d).toFixed(1) + "°";
  function age(ms) {
    if (!num(ms) || ms < 0) return "unknown age";
    const s = Math.round(ms / 1000);
    return s < 90 ? s + " s" : s < 5400 ? Math.round(s / 60) + " min" : s < 172800 ? Math.round(s / 3600) + " h" : Math.round(s / 86400) + " days";
  }
  // Every contract kind reads as words; unknown kinds fall back to their name.
  const KIND_LABEL = { observation: "observation tower", cooling: "cooling tower" };
  const kindLabel = (f) => (f && isKind(f.kind) ? KIND_LABEL[f.kind] || f.kind.replace(/_/g, " ") : "landmark");
  // "2400 m" for terrain, "80 m tall" for structures, "" when unknown.
  const sizeLabel = (f) => (num(f.e) && f.e > 0 ? Math.round(f.e) + (TERRAIN.has(f.kind) ? " m" : " m tall") : "");

  return {
    RADII,
    DEFAULT_RADIUS,
    MAX_MARKS,
    MAX_HORIZON,
    NAME_MAX,
    DATA_ORIGIN,
    INDEX_URL,
    DATA_CONCURRENCY,
    OLD_FIX_MS,
    LONG_WAIT_MS,
    LOCATION_SPACING_MS,
    MAX_SLOTS,
    INDEX_KEY,
    MESSAGE_LIMIT,
    MESSAGE_BUDGET,
    cleanSidecar,
    newSidecar,
    recordKey,
    loadIndex,
    indexValue,
    recordValue,
    recordFor,
    planPut,
    planRelease,
    envelopeLength,
    checkEnvelope,
    persistence,
    listIds,
    associate,
    fixFrom,
    metres,
    chooseViewpoint,
    queryable,
    cellsAround,
    parseIndex,
    cellUrl,
    cellKey,
    cellPlan,
    parseCell,
    featureKey,
    sameFeature,
    coverageNote,
    within,
    cacheKey,
    outsideMessage,
    httpProblem,
    limiter,
    landmarkData,
    search,
    markFrom,
    calibrationInput,
    candidatesOf,
    shortlist,
    positionMatters,
    compass,
    km,
    signed,
    age,
    kindLabel,
    sizeLabel,
  };
})();
if (typeof module !== "undefined") module.exports = AimeCore;
